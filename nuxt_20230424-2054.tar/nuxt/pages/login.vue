<template>
    <userTextField nazv="login" :text.lazy="user.login" :err="errFields" placeholder="Логин" @update="user.login = $event, testFF(false, 'login')" />
    <hr>
    <userTextField nazv="pass" :text.lazy="user.pass" :err="errFields" placeholder=" Пароль" @update="user.pass = $event, testFF(false, 'pass')" />
    <button @click="testFF(true)">Login</button><br>
    <p>
        {{ errFields }}
    </p>
</template>



<script setup>
const storeCart = usePiniaCart();
definePageMeta({
    layout: "custom",
});
useSeoMeta({
    title: `Login`
})
/*  */
const user = ref({
    login: '',
    pass: '',
})
/* Проверка полей */
let errFields = ref({});
async function testFF(write, fieldKey) {
    const apiDalee = "/api/login";
    const fields = ref({});
    if (fieldKey) {
        fields.value[fieldKey] = user.value[fieldKey];
        errFields.value[fieldKey] = (await myCompValidate(apiDalee, fields, write))[fieldKey]

    } else {
        fields.value = user.value;
        errFields.value = await myCompValidate(apiDalee, fields, write);
    }
    if (write && await errFields.value.user === true) {
        storeCart.token = true;
        /* navigateTo({
            path: "/site/user/order-complite"
        }) */
    } else if (write) {
        console.log('авторизировался отклонена');
    }
    //  localStorage.setItem("userData", JSON.stringify(userData.value));
}
/*  */

</script>

