<template>
  <div>
    cart layouts

    <div>
      <slot />
    </div>
  </div>
</template>
