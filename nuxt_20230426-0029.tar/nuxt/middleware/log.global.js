//const storeCart = usePiniaCart();
export default defineNuxtRouteMiddleware((to, from) => {
  //console.log(1111);
  // console.log(from);
  //  console.log(to.path);
});
