<template>
    <h4>
        {{ route.params.cat_name }}
    </h4>
    <div v-if="!pending">
        <ol>
            <div v-if="products.length > 0">
                <div v-for="(product, index) in products" :key="'product' + index">
                    <hr>
                    <div>{{ index + 1 }}. {{ product.name }}</div>
                    <img :src="product.image" alt="">
                    <span>product:{{ product }} | </span><br>
                    <br>
                    <button @click="addToCart(product)">addToCart</button>
                    <hr>
                </div>
            </div>
            <div v-else>В этой категории нет товаров</div>
        </ol>
        <hr>
    </div>
    <div v-else>Загрузка...</div>
    <!-- передаём в компонент TextArea строку и возвращаем редактированую -->
    <!--    <Custominput :text="product.name" @update="product.name = $event"></Custominput> -->

    <!--  -->
</template>

<script setup>
/*  */
const route = useRoute();
definePageMeta({
    layout: "default",
    auth: false
});
useSeoMeta({
    title: route.params.cat_name
})
/*  */

//не передаёт параметры
//const products = ref([]);
const { data: products, pending } = await useLazyFetch('/api/db_products/productsInCategoryAsk', { method: 'POST', body: { cat_name: route.params.cat_name } });
//products.value = await data.value;
//console.log(products.value);

/* const { data: products, pending, refresh: refreshProducts } = await useFetch('/api/products/productsInCatAsk', { method: 'GET', query: { cat_name: route.params.cat_name } }); */

//const products = ref([]);
/* const { data, pending, refresh: refreshProducts } = await useFetch(() => `/api/products/productsInCatAsk`, { query: { cat_name: route.params.cat_name } })
products.value = data.value; */
/*  */


</script>