declare module '#auth' {
  const getServerSession: typeof import('/app/node_modules/@sidebase/nuxt-auth/dist/runtime/server/services').getServerSession
  const getToken: typeof import('/app/node_modules/@sidebase/nuxt-auth/dist/runtime/server/services').getToken
  const NuxtAuthHandler: typeof import('/app/node_modules/@sidebase/nuxt-auth/dist/runtime/server/services').NuxtAuthHandler
}