globalThis._importMeta_={url:import.meta.url,env:process.env};import 'file:///app/node_modules/node-fetch-native/dist/polyfill.mjs';
import { Server } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { mkdirSync } from 'node:fs';
import { parentPort, threadId } from 'node:worker_threads';
import { provider, isWindows } from 'file:///app/node_modules/std-env/dist/index.mjs';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, setResponseStatus, setCookie, appendHeader, getHeaders, createError, parseCookies, getMethod, getQuery, isMethod, readBody, getRequestHeader, setResponseHeader, getRequestHeaders, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'file:///app/node_modules/h3/dist/index.mjs';
import CredentialsProvider from 'file:///app/node_modules/next-auth/providers/credentials.js';
import mysql from 'file:///app/node_modules/mysql2/promise.js';
import nodemailer from 'file:///app/node_modules/nodemailer/lib/nodemailer.js';
import { createRenderer } from 'file:///app/node_modules/vue-bundle-renderer/dist/runtime.mjs';
import devalue from 'file:///app/node_modules/@nuxt/devalue/dist/devalue.mjs';
import { renderToString } from 'file:///app/node_modules/vue/server-renderer/index.mjs';
import { createFetch as createFetch$1, Headers } from 'file:///app/node_modules/ofetch/dist/node.mjs';
import destr from 'file:///app/node_modules/destr/dist/index.mjs';
import { createCall, createFetch } from 'file:///app/node_modules/unenv/runtime/fetch/index.mjs';
import { createHooks } from 'file:///app/node_modules/hookable/dist/index.mjs';
import { snakeCase } from 'file:///app/node_modules/scule/dist/index.mjs';
import defu, { defuFn, defu as defu$1 } from 'file:///app/node_modules/defu/dist/defu.mjs';
import { hash } from 'file:///app/node_modules/ohash/dist/index.mjs';
import { parseURL, withoutBase, joinURL, withQuery } from 'file:///app/node_modules/ufo/dist/index.mjs';
import { createStorage, prefixStorage } from 'file:///app/node_modules/unstorage/dist/index.mjs';
import unstorage_47drivers_47fs from 'file:///app/node_modules/unstorage/drivers/fs.mjs';
import { toRouteMatcher, createRouter } from 'file:///app/node_modules/radix3/dist/index.mjs';
import { AuthHandler } from 'file:///app/node_modules/next-auth/core/index.js';
import { getToken as getToken$1 } from 'file:///app/node_modules/next-auth/jwt/index.js';
import getURL from 'file:///app/node_modules/requrl/dist/requrl.js';

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"envPrefix":"NUXT_","routeRules":{"/__nuxt_error":{"cache":false}}},"public":{"auth":{"isEnabled":true,"origin":"http://localhost:3000","basePath":"/api/auth","trustHost":false,"enableSessionRefreshPeriodically":false,"enableSessionRefreshOnWindowFocus":true,"enableGlobalAppMiddleware":true,"defaultProvider":"","addDefaultCallbackUrl":true,"globalMiddlewareOptions":{"allow404WithoutAuth":true,"addDefaultCallbackUrl":true}}},"mysqlHost":"mf_mysql","mysqlPort":"3306","mysqlUser":"mf_user","mysqlPassword":"mf_user_pass","mysqlDatabase":"mf_mysql_01","emailUser":"admin@serega183.ru","emailPass":"parolAdmin183","emailHost":"smtp.spaceweb.ru","emailPort":25,"emailSecure":false,"appName":"mfNuxt","sendMailToAdminNewOreder":"serega183@mail.ru","auth":{"isEnabled":true,"origin":"http://localhost:3000","basePath":"/api/auth","trustHost":false,"enableSessionRefreshPeriodically":false,"enableSessionRefreshOnWindowFocus":true,"enableGlobalAppMiddleware":true,"defaultProvider":"","addDefaultCallbackUrl":true,"globalMiddlewareOptions":{"allow404WithoutAuth":true,"addDefaultCallbackUrl":true},"isOriginSet":true}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
overrideConfig(_runtimeConfig);
const runtimeConfig = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => runtimeConfig;
deepFreeze(appConfig);
function getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const serverAssets = [{"baseName":"server","dir":"/app/server/assets"}];

const assets = createStorage();

for (const asset of serverAssets) {
  assets.mount(asset.baseName, unstorage_47drivers_47fs({ base: asset.dir }));
}

const storage = createStorage({});

storage.mount('/assets', assets);

storage.mount('root', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"/app","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('src', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"/app/server","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('build', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"/app/.nuxt","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('cache', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"/app/.nuxt/cache","ignore":["**/node_modules/**","**/.git/**"]}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const isNonEmptyObject = (obj) => typeof obj === "object" && Object.keys(obj).length > 0;

function defineRenderHandler(handler) {
  return eventHandler(async (event) => {
    if (event.node.req.url.endsWith("/favicon.ico")) {
      event.node.res.setHeader("Content-Type", "image/x-icon");
      event.node.res.end(
        "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
      );
      return;
    }
    const response = await handler(event);
    if (!response) {
      if (!event.node.res.writableEnded) {
        event.node.res.statusCode = event.node.res.statusCode === 200 ? 500 : event.node.res.statusCode;
        event.node.res.end(
          "No response returned from render handler: " + event.node.req.url
        );
      }
      return;
    }
    const nitroApp = useNitroApp();
    await nitroApp.hooks.callHook("render:response", response, { event });
    if (!event.node.res.headersSent && response.headers) {
      for (const header in response.headers) {
        event.node.res.setHeader(header, response.headers[header]);
      }
      setResponseStatus(event, response.statusCode, response.statusMessage);
    }
    return typeof response.body === "string" ? response.body : JSON.stringify(response.body);
  });
}

function buildAssetsURL(...path) {
  return joinURL(publicAssetsURL(), useRuntimeConfig().app.buildAssetsDir, ...path);
}
function publicAssetsURL(...path) {
  const publicBase = useRuntimeConfig().app.cdnURL || useRuntimeConfig().app.baseURL;
  return path.length ? joinURL(publicBase, ...path) : publicBase;
}

let preparedAuthHandler;
let usedSecret;
const SUPPORTED_ACTIONS = ["providers", "session", "csrf", "signin", "signout", "callback", "verify-request", "error", "_log"];
const ERROR_MESSAGES = {
  NO_SECRET: "AUTH_NO_SECRET: No `secret` - this is an error in production, see https://sidebase.io/nuxt-auth/resources/errors. You can ignore this during development",
  NO_ORIGIN: "AUTH_NO_ORIGIN: No `origin` - this is an error in production, see https://sidebase.io/nuxt-auth/resources/errors. You can ignore this during development"
};
const readBodyForNext = async (event) => {
  let body;
  if (isMethod(event, "PATCH") || isMethod(event, "POST") || isMethod(event, "PUT") || isMethod(event, "DELETE")) {
    body = await readBody(event);
  }
  return body;
};
const parseActionAndProvider = ({ context }) => {
  const params = context.params?._?.split("/");
  if (!params || ![1, 2].includes(params.length)) {
    throw createError({ statusCode: 400, statusMessage: `Invalid path used for auth-endpoint. Supply either one path parameter (e.g., \`/api/auth/session\`) or two (e.g., \`/api/auth/signin/github\` after the base path (in previous examples base path was: \`/api/auth/\`. Received \`${params}\`` });
  }
  const [unvalidatedAction, providerId] = params;
  const action = SUPPORTED_ACTIONS.find((action2) => action2 === unvalidatedAction);
  if (!action) {
    throw createError({ statusCode: 400, statusMessage: `Called endpoint with unsupported action ${unvalidatedAction}. Only the following actions are supported: ${SUPPORTED_ACTIONS.join(", ")}` });
  }
  return { action, providerId };
};
const getServerOrigin = (event) => {
  const envOrigin = process.env.AUTH_ORIGIN;
  if (envOrigin) {
    return envOrigin;
  }
  const runtimeConfigOrigin = useRuntimeConfig().auth.origin;
  if (runtimeConfigOrigin) {
    return runtimeConfigOrigin;
  }
  if (event && "development" !== "production") {
    return getURL(event.node.req);
  }
  throw new Error(ERROR_MESSAGES.NO_ORIGIN);
};
const detectHost = (event, { trusted, basePath }) => {
  if (trusted) {
    const forwardedValue = getURL(event.node.req);
    if (forwardedValue) {
      return Array.isArray(forwardedValue) ? forwardedValue[0] : forwardedValue;
    }
  }
  let origin;
  try {
    origin = getServerOrigin(event);
  } catch (error) {
    return void 0;
  }
  return joinURL(origin, basePath);
};
const NuxtAuthHandler = (nuxtAuthOptions) => {
  usedSecret = nuxtAuthOptions?.secret;
  if (!usedSecret) {
    {
      console.info(ERROR_MESSAGES.NO_SECRET);
      usedSecret = "secret";
    }
  }
  const options = defu$1(nuxtAuthOptions, {
    secret: usedSecret,
    logger: void 0,
    providers: [],
    trustHost: useRuntimeConfig().auth.trustHost
  });
  const getInternalNextAuthRequestData = async (event) => {
    const nextRequest = {
      host: detectHost(event, { trusted: useRuntimeConfig().auth.trustHost, basePath: useRuntimeConfig().auth.basePath }),
      body: void 0,
      cookies: parseCookies(event),
      query: void 0,
      headers: getHeaders(event),
      method: getMethod(event),
      providerId: void 0,
      error: void 0
    };
    if (event.context.checkSessionOnNonAuthRequest === true) {
      return {
        ...nextRequest,
        method: "GET",
        action: "session"
      };
    }
    const query = getQuery(event);
    const { action, providerId } = parseActionAndProvider(event);
    const error = query.error;
    if (Array.isArray(error)) {
      throw createError({ statusCode: 400, statusMessage: "Error query parameter can only appear once" });
    }
    const body = await readBodyForNext(event);
    return {
      ...nextRequest,
      body,
      query,
      action,
      providerId,
      error: String(error) || void 0
    };
  };
  const handler = eventHandler(async (event) => {
    const { res } = event.node;
    const nextRequest = await getInternalNextAuthRequestData(event);
    const nextResult = await AuthHandler({
      req: nextRequest,
      options
    });
    if (nextResult.status) {
      res.statusCode = nextResult.status;
    }
    nextResult.cookies?.forEach((cookie) => setCookie(event, cookie.name, cookie.value, cookie.options));
    nextResult.headers?.forEach((header) => appendHeader(event, header.key, header.value));
    if (!nextResult.redirect) {
      return nextResult.body;
    }
    if (nextRequest.body?.json) {
      return { url: nextResult.redirect };
    }
    return sendRedirect(event, nextResult.redirect);
  });
  if (preparedAuthHandler) {
    console.warn("You setup the auth handler for a second time - this is likely undesired. Make sure that you only call `NuxtAuthHandler( ... )` once");
  }
  preparedAuthHandler = handler;
  return handler;
};
const getServerSession = async (event) => {
  const authBasePath = useRuntimeConfig().public.auth.basePath;
  if (event.path && event.path.startsWith(authBasePath)) {
    return null;
  }
  if (!preparedAuthHandler) {
    const headers = getHeaders(event);
    await $fetch(joinURL(authBasePath, "/session"), {
      headers
    }).catch((error) => error.data);
    if (!preparedAuthHandler) {
      throw createError({ statusCode: 500, statusMessage: "Tried to get server session without setting up an endpoint to handle authentication (see https://github.com/sidebase/nuxt-auth#quick-start)" });
    }
  }
  event.context.checkSessionOnNonAuthRequest = true;
  const session = await preparedAuthHandler(event);
  delete event.context.checkSessionOnNonAuthRequest;
  if (isNonEmptyObject(session)) {
    return session;
  }
  return null;
};
const getToken = ({ event, secureCookie, secret, ...rest }) => getToken$1({
  // @ts-expect-error As our request is not a real next-auth request, we pass down only what's required for the method, as per code from https://github.com/nextauthjs/next-auth/blob/8387c78e3fef13350d8a8c6102caeeb05c70a650/packages/next-auth/src/jwt/index.ts#L68
  req: {
    cookies: parseCookies(event),
    headers: getHeaders(event)
  },
  // see https://github.com/nextauthjs/next-auth/blob/8387c78e3fef13350d8a8c6102caeeb05c70a650/packages/next-auth/src/jwt/index.ts#L73
  secureCookie: secureCookie || getServerOrigin(event).startsWith("https://"),
  secret: secret || usedSecret,
  ...rest
});

function defineNitroPlugin(def) {
  return def;
}
const _GrYOmuseDW = defineNitroPlugin(() => {
  try {
    getServerOrigin();
  } catch (error) {
    {
      console.info(ERROR_MESSAGES.NO_ORIGIN);
    }
  }
});

const plugins = [
  _GrYOmuseDW
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: statusCode !== 404 ? `<pre>${stack.map((i) => `<span class="stack${i.internal ? " internal" : ""}">${i.text}</span>`).join("\n")}</pre>` : "",
    data: error.data
  };
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await Promise.resolve().then(function () { return errorDev; }) ;
    {
      errorObject.description = errorObject.message;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  event.node.res.end(await res.text());
});

const _lazy_Altfih = () => Promise.resolve().then(function () { return _____$1; });
const _lazy_4OGGIC = () => Promise.resolve().then(function () { return sendMailVerification$1; });
const _lazy_kwrX8e = () => Promise.resolve().then(function () { return sendPass$1; });
const _lazy_Cdpocb = () => Promise.resolve().then(function () { return sendTokenForMailConfirm$1; });
const _lazy_8HzMfy = () => Promise.resolve().then(function () { return categoriesAskAll_copy$1; });
const _lazy_EVyUfN = () => Promise.resolve().then(function () { return categoriesAskAll$1; });
const _lazy_MULN3p = () => Promise.resolve().then(function () { return categoriesAskOne$1; });
const _lazy_cvOmPF = () => Promise.resolve().then(function () { return categoryAdd$1; });
const _lazy_OWhGso = () => Promise.resolve().then(function () { return categoryDell$1; });
const _lazy_ewdoHR = () => Promise.resolve().then(function () { return categoryEdit$1; });
const _lazy_nc3dbS = () => Promise.resolve().then(function () { return order_delete$1; });
const _lazy_fJsB20 = () => Promise.resolve().then(function () { return ordersAll$1; });
const _lazy_3aAdtN = () => Promise.resolve().then(function () { return orderStatus_post$1; });
const _lazy_ts6qKV = () => Promise.resolve().then(function () { return writeOrder$1; });
const _lazy_RWC0Qc = () => Promise.resolve().then(function () { return findProduct$1; });
const _lazy_GtBeHW = () => Promise.resolve().then(function () { return productAdd$1; });
const _lazy_pKRz0T = () => Promise.resolve().then(function () { return productDell$1; });
const _lazy_7edgc7 = () => Promise.resolve().then(function () { return productEdit$1; });
const _lazy_DzKPH8 = () => Promise.resolve().then(function () { return productsAskAll$1; });
const _lazy_w5Uk9g = () => Promise.resolve().then(function () { return productsAskOne$1; });
const _lazy_RdYxCH = () => Promise.resolve().then(function () { return productsInCategoryAsk$1; });
const _lazy_EcIZmm = () => Promise.resolve().then(function () { return userAdd$1; });
const _lazy_eVmVyk = () => Promise.resolve().then(function () { return userDuplicateFind$1; });
const _lazy_PzAz22 = () => Promise.resolve().then(function () { return userGet$1; });
const _lazy_BPbA58 = () => Promise.resolve().then(function () { return writeOrderToUser$1; });
const _lazy_knzjsg = () => Promise.resolve().then(function () { return createUserForVerificationEmail$1; });
const _lazy_hGkfYA = () => Promise.resolve().then(function () { return hello$1; });
const _lazy_oJPq80 = () => Promise.resolve().then(function () { return loadSleep$1; });
const _lazy_Vr4zqJ = () => Promise.resolve().then(function () { return sendMail$1; });
const _lazy_vPoECr = () => Promise.resolve().then(function () { return testApiDalee$1; });
const _lazy_mGicTm = () => Promise.resolve().then(function () { return validateFieldsRules$1; });
const _lazy_1AROdB = () => Promise.resolve().then(function () { return renderer$1; });

const handlers = [
  { route: '/api/auth/**', handler: _lazy_Altfih, lazy: true, middleware: false, method: undefined },
  { route: '/api/auth/sendMailVerification', handler: _lazy_4OGGIC, lazy: true, middleware: false, method: undefined },
  { route: '/api/auth/sendPass', handler: _lazy_kwrX8e, lazy: true, middleware: false, method: undefined },
  { route: '/api/auth/sendTokenForMailConfirm', handler: _lazy_Cdpocb, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_categories/categoriesAskAll copy', handler: _lazy_8HzMfy, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_categories/categoriesAskAll', handler: _lazy_EVyUfN, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_categories/categoriesAskOne', handler: _lazy_MULN3p, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_categories/categoryAdd', handler: _lazy_cvOmPF, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_categories/categoryDell', handler: _lazy_OWhGso, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_categories/categoryEdit', handler: _lazy_ewdoHR, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_orders/order', handler: _lazy_nc3dbS, lazy: true, middleware: false, method: "delete" },
  { route: '/api/db_orders/ordersAll', handler: _lazy_fJsB20, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_orders/orderStatus', handler: _lazy_3aAdtN, lazy: true, middleware: false, method: "post" },
  { route: '/api/db_orders/writeOrder', handler: _lazy_ts6qKV, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/findProduct', handler: _lazy_RWC0Qc, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/productAdd', handler: _lazy_GtBeHW, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/productDell', handler: _lazy_pKRz0T, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/productEdit', handler: _lazy_7edgc7, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/productsAskAll', handler: _lazy_DzKPH8, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/productsAskOne', handler: _lazy_w5Uk9g, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_products/productsInCategoryAsk', handler: _lazy_RdYxCH, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_users/userAdd', handler: _lazy_EcIZmm, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_users/userDuplicateFind', handler: _lazy_eVmVyk, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_users/userGet', handler: _lazy_PzAz22, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_users/writeOrderToUser', handler: _lazy_BPbA58, lazy: true, middleware: false, method: undefined },
  { route: '/api/db_usersNoVerificatedEmail/createUserForVerificationEmail', handler: _lazy_knzjsg, lazy: true, middleware: false, method: undefined },
  { route: '/api/test/hello', handler: _lazy_hGkfYA, lazy: true, middleware: false, method: undefined },
  { route: '/api/test/loadSleep', handler: _lazy_oJPq80, lazy: true, middleware: false, method: undefined },
  { route: '/api/test/sendMail', handler: _lazy_Vr4zqJ, lazy: true, middleware: false, method: undefined },
  { route: '/api/test/testApiDalee', handler: _lazy_vPoECr, lazy: true, middleware: false, method: undefined },
  { route: '/api/validateFieldsRules', handler: _lazy_mGicTm, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_1AROdB, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_1AROdB, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(true),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: $fetch });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const server = new Server(toNodeListener(nitroApp.h3App));
function getAddress() {
  if (provider === "stackblitz" || process.env.NITRO_NO_UNIX_SOCKET) {
    return "0";
  }
  const socketName = `worker-${process.pid}-${threadId}.sock`;
  if (isWindows) {
    return join("\\\\.\\pipe\\nitro", socketName);
  } else {
    const socketDir = join(tmpdir(), "nitro");
    mkdirSync(socketDir, { recursive: true });
    return join(socketDir, socketName);
  }
}
const listenAddress = getAddress();
server.listen(listenAddress, () => {
  const _address = server.address();
  parentPort.postMessage({
    event: "listen",
    address: typeof _address === "string" ? { socketPath: _address } : { host: "localhost", port: _address.port }
  });
});
{
  process.on(
    "unhandledRejection",
    (err) => console.error("[nitro] [dev] [unhandledRejection]", err)
  );
  process.on(
    "uncaughtException",
    (err) => console.error("[nitro] [dev] [uncaughtException]", err)
  );
}

const _messages = {"appName":"Nuxt","version":"","statusCode":500,"statusMessage":"Server error","description":"An error occurred in the application and the page could not be served. If you are the application owner, check your server logs for details.","stack":""};
const _render = function({ messages }) {
var __t, __p = '';
__p += '<!DOCTYPE html><html><head><title>' +
((__t = ( messages.statusCode )) == null ? '' : __t) +
' - ' +
((__t = ( messages.statusMessage )) == null ? '' : __t) +
' | ' +
((__t = ( messages.appName )) == null ? '' : __t) +
'</title><meta charset="utf-8"><meta content="width=device-width,initial-scale=1,minimum-scale=1" name="viewport"><style>.spotlight{background:linear-gradient(45deg, #00DC82 0%, #36E4DA 50%, #0047E1 100%);opacity:0.8;filter:blur(30vh);height:60vh;bottom:-40vh}*,:before,:after{-webkit-box-sizing:border-box;box-sizing:border-box;border-width:0;border-style:solid;border-color:#e0e0e0}*{--tw-ring-inset:var(--tw-empty, );--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(14, 165, 233, .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000}:root{-moz-tab-size:4;-o-tab-size:4;tab-size:4}body{margin:0;font-family:inherit;line-height:inherit}html{-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5}h1,p,pre{margin:0}h1{font-size:inherit;font-weight:inherit}pre{font-size:1em;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace}.bg-white{--tw-bg-opacity:1;background-color:rgba(255,255,255,var(--tw-bg-opacity))}.bg-black\\/5{--tw-bg-opacity:.05;background-color:rgba(0,0,0,var(--tw-bg-opacity))}.rounded-t-md{border-top-left-radius:.375rem;border-top-right-radius:.375rem}.flex{display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.flex-col{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;-webkit-flex-direction:column;flex-direction:column}.flex-1{-webkit-box-flex:1;-ms-flex:1 1 0%;-webkit-flex:1 1 0%;flex:1 1 0%}.font-sans{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji"}.font-medium{font-weight:500}.font-light{font-weight:300}.h-auto{height:auto}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-6xl{font-size:3.75rem;line-height:1}.leading-tight{line-height:1.25}.mb-8{margin-bottom:2rem}.mb-6{margin-bottom:1.5rem}.min-h-screen{min-height:100vh}.overflow-y-auto{overflow-y:auto}.p-8{padding:2rem}.px-10{padding-left:2.5rem;padding-right:2.5rem}.pt-14{padding-top:3.5rem}.fixed{position:fixed}.left-0{left:0px}.right-0{right:0px}.text-black{--tw-text-opacity:1;color:rgba(0,0,0,var(--tw-text-opacity))}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.z-10{z-index:10}@media (min-width: 640px){.sm\\:text-8xl{font-size:6rem;line-height:1}.sm\\:text-2xl{font-size:1.5rem;line-height:2rem}}@media (prefers-color-scheme: dark){.dark\\:bg-black{--tw-bg-opacity:1;background-color:rgba(0,0,0,var(--tw-bg-opacity))}.dark\\:bg-white\\/10{--tw-bg-opacity:.1;background-color:rgba(255,255,255,var(--tw-bg-opacity))}.dark\\:text-white{--tw-text-opacity:1;color:rgba(255,255,255,var(--tw-text-opacity))}}</style><script>(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll(\'link[rel="modulepreload"]\'))n(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function i(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerpolicy&&(r.referrerPolicy=e.referrerpolicy),e.crossorigin==="use-credentials"?r.credentials="include":e.crossorigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(e){if(e.ep)return;e.ep=!0;const r=i(e);fetch(e.href,r)}})();</script></head><body class="font-sans antialiased bg-white px-10 pt-14 dark:bg-black text-black dark:text-white min-h-screen flex flex-col"><div class="fixed left-0 right-0 spotlight"></div><h1 class="text-6xl sm:text-8xl font-medium mb-6">' +
((__t = ( messages.statusCode )) == null ? '' : __t) +
'</h1><p class="text-xl sm:text-2xl font-light mb-8 leading-tight">' +
((__t = ( messages.description )) == null ? '' : __t) +
'</p><div class="bg-white rounded-t-md bg-black/5 dark:bg-white/10 flex-1 overflow-y-auto h-auto"><pre class="text-xl font-light leading-tight z-10 p-8">' +
((__t = ( messages.stack )) == null ? '' : __t) +
'</pre></div></body></html>';
return __p
};
const _template = (messages) => _render({ messages: { ..._messages, ...messages } });
const template = _template;

const errorDev = /*#__PURE__*/Object.freeze({
      __proto__: null,
      template: template
});

const _____ = NuxtAuthHandler({
  // секрет, необходимый для запуска nuxt-auth в рабочем режиме (используется для шифрования данных)
  secret: "process.env.NUXT_SECRET",
  pages: {
    // Измените поведение по умолчанию, чтобы использовать `/login` в качестве пути к странице входа
    signIn: "/site/user/auth/login"
  },
  callbacks: {
    // Обратный вызов при создании / обновлении JWT, см. https://next-auth.js.org/configuration/callbacks#jwt-callback
    jwt: async ({ token, user }) => {
      const isSignIn = user ? true : false;
      if (isSignIn) {
        token.role = user ? user.role || "" : "";
        token.phone = user ? user.phone || "" : "";
        token.email = user ? user.email || "" : "";
      }
      return Promise.resolve(token);
    },
    // Обратный вызов всякий раз, когда проверяется сеанс, см. https://next-auth.js.org/configuration/callbacks#session-callback
    session: async ({ session, token }) => {
      session.user.role = token.role;
      session.user.phone = token.phone;
      session.user.email = token.email;
      return Promise.resolve(session);
    },
    async redirect({ url, baseUrl }) {
      return url;
    }
  },
  providers: [
    CredentialsProvider.default({
      // Имя, отображаемое в форме входа (например, "Войдите с помощью...")
      name: "Credentials",
      // Учетные данные используются для создания подходящей формы на странице входа.
      // Вы можете указать любые поля, которые, как вы ожидаете, будут отправлены.
      // например, домен, имя пользователя, пароль, токен 2FA и т.д.
      // Вы можете передать любой HTML-атрибут тегу <input> через объект.
      credentials: {
        username: { label: "qqq", type: "text", placeholder: "(hint: qqq)" },
        password: { label: "qqq", type: "password", placeholder: "(hint: qqq)" }
      },
      async authorize(credentials) {
        const runtimeConfig = useRuntimeConfig();
        const con = await mysql.createConnection({
          host: runtimeConfig.mysqlHost,
          port: runtimeConfig.mysqlPort,
          user: runtimeConfig.mysqlUser,
          password: runtimeConfig.mysqlPassword,
          database: runtimeConfig.mysqlDatabase
        });
        const [user] = await con.query(
          `select * from users WHERE email LIKE "%${credentials == null ? void 0 : credentials.email}%"`
        );
        con.end();
        if ((credentials == null ? void 0 : credentials.email) === user[0].email && (credentials == null ? void 0 : credentials.password) === user[0].password) {
          return user[0];
        } else {
          return null;
        }
      }
    })
  ]
});

const _____$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: _____
});

const sendMailVerification = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const { email, token } = await readBody(event);
  async function main() {
    let transporter = nodemailer.createTransport({
      host: runtimeConfig.emailHost,
      port: runtimeConfig.emailPort,
      secure: runtimeConfig.emailSecure,
      // true for 465, false for other ports
      auth: {
        user: runtimeConfig.emailUser,
        // generated ethereal user
        pass: runtimeConfig.emailPass
        // generated ethereal password
      }
    });
    await transporter.sendMail({
      from: `${runtimeConfig.appName} <admin@serega183.ru>`,
      // sender address
      to: email,
      // list of receivers
      subject: `${runtimeConfig.appName} \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F`,
      // Subject line
      text: token,
      // plain text body
      html: `<b>\u041A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F: ${token}</b>`
      // html body
    }).catch((err) => {
      return { err };
    });
    return true;
  }
  return main();
});

const sendMailVerification$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: sendMailVerification
});

const sendPass = defineEventHandler(async (event) => {
  useRuntimeConfig();
  const { fields, write } = await readBody(event);
  if (typeof fields["email"] !== "undefined") {
    fields.email.needValidate = {
      isEmail: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const user = await $fetch("/api/db_users/userGet", {
        method: "POST",
        body: { email: fields.email.input }
      });
      if (user) {
        return await sendMail$2(user.email, user.password);
      } else {
        return { user: false };
      }
    }
    return validatefields;
  }
});
async function sendMail$2(email, pass) {
  const runtimeConfig = useRuntimeConfig();
  let transporter = nodemailer.createTransport({
    host: runtimeConfig.emailHost,
    port: runtimeConfig.emailPort,
    secure: runtimeConfig.emailSecure,
    // true for 465, false for other ports
    auth: {
      user: runtimeConfig.emailUser,
      // generated ethereal user
      pass: runtimeConfig.emailPass
      // generated ethereal password
    }
  });
  await transporter.sendMail({
    from: `${runtimeConfig.appName} <admin@serega183.ru>`,
    // sender address
    to: email,
    // list of receivers
    subject: `${runtimeConfig.appName} \u0412\u0430\u0448 \u043F\u0430\u0440\u043E\u043B\u044C`,
    // Subject line
    text: pass,
    // plain text body
    html: `<b>\u041F\u0430\u0440\u043E\u043B\u044C: ${pass}</b>`
    // html body
  }).catch((err) => {
    return { err };
  });
  return true;
}

const sendPass$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: sendPass
});

const sendTokenForMailConfirm = defineEventHandler(async (event) => {
  const { token, email } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  try {
    const data = [token];
    const sql = `select * from usersNoVerificatedEmail WHERE email='${email}'`;
    const [rows] = await con.execute(sql);
    if (rows[0].token == token) {
      const user = [rows[0].name, rows[0].phone, rows[0].email, rows[0].password];
      const sql2 = `INSERT INTO users SET name=?, phone=?, email=?, password=?`;
      const doblUser = await $fetch("/api/db_users/userDuplicateFind", {
        method: "POST",
        body: { email: rows[0].email }
      });
      if (doblUser) {
        con.query(`DELETE FROM users WHERE email='${rows[0].email}'`);
      }
      const add = con.query(sql2, user);
      con.query(`DELETE FROM usersNoVerificatedEmail WHERE email='${rows[0].email}'`);
      con.end();
      return true;
    } else if (rows[0].try > 0) {
      con.execute(
        `UPDATE usersNoVerificatedEmail SET try = try - 1 WHERE email='${rows[0].email}'`
      );
      con.end();
      return false;
    } else {
      return "resend";
    }
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. usersNoVerificatedEmail. ${error}`;
  }
});

const sendTokenForMailConfirm$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: sendTokenForMailConfirm
});

const categoriesAskAll_copy = defineEventHandler(async (event) => {
  const [rows] = await event.context.db_mf_mysql_01.execute("select * from categories");
  return rows;
});

const categoriesAskAll_copy$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: categoriesAskAll_copy
});

const categoriesAskAll = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const [rows] = await con.query("select * from categories");
  con.end();
  return rows;
});

const categoriesAskAll$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: categoriesAskAll
});

const categoriesAskOne = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const query = getQuery(event);
  const [rows] = await con.execute(`select * from categories WHERE id_cat=${query.id}`);
  con.end();
  return rows[0];
});

const categoriesAskOne$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: categoriesAskOne
});

const categoryAdd = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["cat_name"] !== "undefined") {
    fields.cat_name.needValidate = {
      minLength: 3
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const cat = [fields.cat_name.input, fields.cat_discr.input, fields.cat_img.input];
      const sql = "INSERT INTO `categories`(`cat_name`, `cat_discr`, `cat_img`) VALUES(?, ?, ?)";
      try {
        const runtimeConfig = useRuntimeConfig();
        const con2 = await mysql.createConnection({
          host: runtimeConfig.mysqlHost,
          port: runtimeConfig.mysqlPort,
          user: runtimeConfig.mysqlUser,
          password: runtimeConfig.mysqlPassword,
          database: runtimeConfig.mysqlDatabase
        });
        const add = await con2.query(sql, cat);
        con2.end();
        return true;
      } catch (error) {
        con.end();
        return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. categoryAdd. ${error}`;
      }
    }
    return validatefields;
  }
});

const categoryAdd$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: categoryAdd
});

const categoryDell = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const qu = getQuery(event);
  await con.query(`DELETE FROM categories WHERE id_cat=${qu.id_cat}`);
  con.end();
  return "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u0443\u0434\u0430\u043B\u0435\u043D\u0430";
});

const categoryDell$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: categoryDell
});

const categoryEdit = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["cat_name"] !== "undefined") {
    fields.cat_name.needValidate = {
      minLength: 3
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const data = [fields.cat_name.input, fields.cat_discr.input, fields.cat_img.input];
      const sql = `UPDATE categories SET cat_name=?, cat_discr=?, cat_img=? WHERE id_cat=${fields.id_cat.input}`;
      try {
        const runtimeConfig = useRuntimeConfig();
        const con2 = await mysql.createConnection({
          host: runtimeConfig.mysqlHost,
          port: runtimeConfig.mysqlPort,
          user: runtimeConfig.mysqlUser,
          password: runtimeConfig.mysqlPassword,
          database: runtimeConfig.mysqlDatabase
        });
        const edit = await con2.query(sql, data);
        con2.end();
        return true;
      } catch (error) {
        con.end();
        return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. categoryEdit. ${error}`;
      }
    }
    return validatefields;
  }
});

const categoryEdit$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: categoryEdit
});

const order_delete = defineEventHandler(async (event) => {
  const { id } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  await con.query(`DELETE FROM orders WHERE id=${id}`);
  con.end();
  return "\u0423\u0434\u0430\u043B\u0435\u043D\u043E";
});

const order_delete$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: order_delete
});

const ordersAll = defineEventHandler(async (event) => {
  const resp = {
    err: null,
    resp: null
  };
  const session = await getServerSession(event);
  if (!session) {
    resp.err = "unauthenticated";
    return resp;
  }
  console.log(session.role);
  await getToken({ event });
  const { filterStatus, filterDate } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  let sql = ``;
  if (filterDate == "\u0412\u0441\u0435" && filterStatus == "\u0412\u0441\u0435") {
    sql = `select * from orders`;
  } else if (filterDate == "\u0412\u0441\u0435" && filterStatus != "\u0412\u0441\u0435") {
    sql = `select * from orders WHERE status='${filterStatus}'`;
  } else if (filterDate != "\u0412\u0441\u0435" && filterStatus == "\u0412\u0441\u0435") {
    sql = `select * from orders WHERE date BETWEEN '${filterDate.ot}' AND '${filterDate.do}'`;
  } else if (filterDate != "\u0412\u0441\u0435" && filterStatus != "\u0412\u0441\u0435") {
    sql = `select * from orders WHERE date BETWEEN '${filterDate.ot}' AND '${filterDate.do}' AND status='${filterStatus}'`;
  }
  try {
    const [rows] = await con.query(sql);
    resp.resp = rows;
    con.end();
    return resp;
  } catch (error) {
    resp.err = `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. ordersAll. ${error}`;
    return resp;
  }
});

const ordersAll$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: ordersAll
});

const orderStatus_post = defineEventHandler(async (event) => {
  const { id, status } = await readBody(event);
  console.log(id, status);
  const sql = `UPDATE orders SET status=? WHERE id=${id}`;
  try {
    const runtimeConfig = useRuntimeConfig();
    const con2 = await mysql.createConnection({
      host: runtimeConfig.mysqlHost,
      port: runtimeConfig.mysqlPort,
      user: runtimeConfig.mysqlUser,
      password: runtimeConfig.mysqlPassword,
      database: runtimeConfig.mysqlDatabase
    });
    const edit = await con2.query(sql, status);
    con2.end();
    return true;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. categoryEdit. ${error}`;
  }
});

const orderStatus_post$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: orderStatus_post
});

const writeOrder = defineEventHandler(async (event) => {
  const { fields, write, cart, date } = await readBody(event);
  if (typeof fields["name"] !== "undefined") {
    fields.name.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["phone"] !== "undefined") {
    fields.phone.needValidate = {
      isPhone: true
    };
  }
  if (typeof fields["street"] !== "undefined") {
    fields.street.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["house"] !== "undefined") {
    fields.house.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["apartment"] !== "undefined") {
    fields.apartment.needValidate = {
      isEmpty: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (await validatefields instanceof Object) {
    return await validatefields;
  } else {
    if (write) {
      for (const key in fields) {
        fields[key].input;
      }
      const order = [
        fields.name.input,
        Number(fields.phone.input),
        fields.street.input,
        fields.house.input,
        fields.apartment.input,
        fields.comment.input,
        JSON.stringify(cart),
        date.date,
        date.time
      ];
      const sql = `INSERT INTO orders SET name=?, phone=?, street=?, house=?, apartment=?, comment=?, cart=?, date=?, time=?`;
      const runtimeConfig = useRuntimeConfig();
      const con = await mysql.createConnection({
        host: runtimeConfig.mysqlHost,
        port: runtimeConfig.mysqlPort,
        user: runtimeConfig.mysqlUser,
        password: runtimeConfig.mysqlPassword,
        database: runtimeConfig.mysqlDatabase
      });
      try {
        const add = await con.query(sql, order);
        con.end();
        return await sendMailToAdminNewOreder(add[0].insertId);
      } catch (error) {
        con.end();
        return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. writeOrder. ${error}`;
      }
    }
    return await validatefields;
  }
});
async function sendMailToAdminNewOreder(id) {
  const runtimeConfig = useRuntimeConfig();
  let transporter = nodemailer.createTransport({
    host: runtimeConfig.emailHost,
    port: runtimeConfig.emailPort,
    secure: runtimeConfig.emailSecure,
    // true for 465, false for other ports
    auth: {
      user: runtimeConfig.emailUser,
      // generated ethereal user
      pass: runtimeConfig.emailPass
      // generated ethereal password
    }
  });
  await transporter.sendMail({
    from: `${runtimeConfig.appName} <admin@serega183.ru>`,
    // sender address
    to: runtimeConfig.sendMailToAdminNewOreder,
    // list of receivers
    subject: `${runtimeConfig.appName} \u041D\u043E\u0432\u044B\u0439 \u0437\u0430\u043A\u0430\u0437`,
    // Subject line
    text: "\u041D\u043E\u0432\u044B\u0439 \u0437\u0430\u043A\u0430\u0437",
    // plain text body
    html: `<b>\u041D\u043E\u0432\u044B\u0439 \u0437\u0430\u043A\u0430\u0437 ${id}</b>`
    // html body
  }).catch((err) => {
    return { err };
  });
  return true;
}

const writeOrder$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: writeOrder
});

const findProduct = defineEventHandler(async (event) => {
  const { findProduct } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const [rows] = await con.query(`select * from products WHERE name LIKE "%${findProduct}%"`);
  con.end();
  return rows;
});

const findProduct$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: findProduct
});

const productAdd = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["category"] !== "undefined") {
    fields.category.needValidate = {
      isCheckCategory: true
    };
  }
  if (typeof fields["name"] !== "undefined") {
    fields.name.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["edinic"] !== "undefined") {
    fields.edinic.needValidate = {
      isEmpty: true,
      isDigit: true
    };
  }
  if (typeof fields["units"] !== "undefined") {
    fields.units.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["price"] !== "undefined") {
    fields.price.needValidate = {
      isEmpty: true,
      isDigit: true
    };
  }
  if (typeof fields["balance"] !== "undefined") {
    fields.balance.needValidate = {
      isEmpty: true,
      isDigit: true
    };
  }
  if (typeof fields["stock"] !== "undefined") {
    fields.stock.needValidate = {
      isStock: true
    };
  }
  if (typeof fields["rating"] !== "undefined") {
    fields.rating.needValidate = {
      isDigit: true,
      isRating: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const runtimeConfig = useRuntimeConfig();
      const con = await mysql.createConnection({
        host: runtimeConfig.mysqlHost,
        port: runtimeConfig.mysqlPort,
        user: runtimeConfig.mysqlUser,
        password: runtimeConfig.mysqlPassword,
        database: runtimeConfig.mysqlDatabase
      });
      const prod = [
        fields.name.input,
        fields.category.input,
        fields.edinic.input,
        fields.units.input,
        fields.price.input,
        fields.balance.input,
        fields.stock.input,
        fields.image.input,
        fields.description.input,
        fields.rating.input,
        fields.maker.input,
        fields.param1.input,
        fields.param2.input,
        fields.param3.input,
        fields.publicationdate.input
      ];
      const sql = "INSERT INTO `products`(`name`, `category`, `edinic`, `units`, `price`, `balance`, `stock`, `image`, `description`, `rating`, `maker`, `param1`, `param2`, `param3`, `publicationdate`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      try {
        const add = await con.query(sql, prod);
        con.end();
        return true;
      } catch (error) {
        con.end();
        return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. productAdd. ${error}`;
      }
    }
    return validatefields;
  }
});

const productAdd$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: productAdd
});

const productDell = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const qu = getQuery(event);
  await con.query(`DELETE FROM products WHERE id=${qu.id}`);
  con.end();
  return "\u0423\u0434\u0430\u043B\u0435\u043D\u043E";
});

const productDell$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: productDell
});

const productEdit = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["category"] !== "undefined") {
    fields.category.needValidate = {
      isCheckCategory: true
    };
  }
  if (typeof fields["name"] !== "undefined") {
    fields.name.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["edinic"] !== "undefined") {
    fields.edinic.needValidate = {
      isEmpty: true,
      isDigit: true
    };
  }
  if (typeof fields["units"] !== "undefined") {
    fields.units.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["price"] !== "undefined") {
    fields.price.needValidate = {
      isEmpty: true,
      isDigit: true
    };
  }
  if (typeof fields["balance"] !== "undefined") {
    fields.balance.needValidate = {
      isEmpty: true,
      isDigit: true
    };
  }
  if (typeof fields["stock"] !== "undefined") {
    fields.stock.needValidate = {
      isStock: true
    };
  }
  if (typeof fields["rating"] !== "undefined") {
    fields.rating.needValidate = {
      isDigit: true,
      isRating: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const runtimeConfig = useRuntimeConfig();
      const con = await mysql.createConnection({
        host: runtimeConfig.mysqlHost,
        port: runtimeConfig.mysqlPort,
        user: runtimeConfig.mysqlUser,
        password: runtimeConfig.mysqlPassword,
        database: runtimeConfig.mysqlDatabase
      });
      const prod = [
        fields.name.input,
        fields.category.input,
        fields.edinic.input,
        fields.units.input,
        fields.price.input,
        fields.balance.input,
        fields.stock.input,
        fields.image.input,
        fields.description.input,
        fields.rating.input,
        fields.maker.input,
        fields.param1.input,
        fields.param2.input,
        fields.param3.input,
        fields.publicationdate.input
      ];
      const sql = `UPDATE products SET name=?, category=?, edinic=?, units=?, price=?, balance=?, stock=?, image=?, description=?, rating=?, maker=?, param1=?, param2=?, param3=?, publicationdate=? WHERE id=${fields.id.input}`;
      try {
        const edit = await con.query(sql, prod);
        con.end();
        return true;
      } catch (error) {
        con.end();
        return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. productEdit. ${error}`;
      }
    }
    return validatefields;
  }
});

const productEdit$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: productEdit
});

const productsAskAll = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const [rows] = await con.execute("select * from products");
  con.end();
  return rows;
});

const productsAskAll$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: productsAskAll
});

const productsAskOne = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const qu = getQuery(event);
  const [rows] = await con.query(`select * from products WHERE id=${qu.id}`);
  con.end();
  return rows[0];
});

const productsAskOne$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: productsAskOne
});

const productsInCategoryAsk = defineEventHandler(async (event) => {
  const { cat_name } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const [rows] = await con.query(`select * from products WHERE category LIKE "%${cat_name}%"`);
  con.end();
  return rows;
});

const productsInCategoryAsk$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: productsInCategoryAsk
});

const userAdd = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["name"] !== "undefined") {
    fields.name.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["phone"] !== "undefined") {
    fields.phone.needValidate = {
      isPhone: true
    };
  }
  if (typeof fields["email"] !== "undefined") {
    fields.email.needValidate = {
      isEmail: true
    };
  }
  if (typeof fields["pass"] !== "undefined") {
    fields.pass.needValidate = {
      isEmpty: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const doblMail = await $fetch("/api/db_users/userDuplicateFind", {
        method: "POST",
        body: { email: fields.email.input }
      });
      if (doblMail) {
        return { email: ["\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0441 \u0442\u0430\u043A\u0438\u043C email \u0443\u0436\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D"] };
      }
      const createUserForVerificationEmail = await $fetch(
        "/api/db_usersNoVerificatedEmail/createUserForVerificationEmail",
        {
          method: "POST",
          body: fields
        }
      );
      return createUserForVerificationEmail;
    }
    return validatefields;
  }
});

const userAdd$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: userAdd
});

const userDuplicateFind = defineEventHandler(async (event) => {
  const { email } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  try {
    const [rows] = await con.execute(`select * from users WHERE email='${email}'`);
    con.end();
    return rows[0] ? rows[0] : false;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. login. ${error}`;
  }
});

const userDuplicateFind$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: userDuplicateFind
});

const userGet = defineEventHandler(async (event) => {
  const { email } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  try {
    const [rows] = await con.execute(`select * from users WHERE email='${email}'`);
    con.end();
    return rows[0] ? rows[0] : false;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. login. ${error}`;
  }
});

const userGet$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: userGet
});

const writeOrderToUser = defineEventHandler(async (event) => {
  const { email, id } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  let [ord] = await con.execute(`SELECT orders_id FROM users WHERE email='${email}'`);
  if (!ord[0].orders_id) {
    ord[0].orders_id = [id];
  } else {
    ord[0].orders_id.push(id);
  }
  const orders = ord[0].orders_id;
  const data = [JSON.stringify(orders)];
  const sql = `UPDATE users SET orders_id=? WHERE email='${email}'`;
  try {
    const runtimeConfig2 = useRuntimeConfig();
    const con2 = await mysql.createConnection({
      host: runtimeConfig2.mysqlHost,
      port: runtimeConfig2.mysqlPort,
      user: runtimeConfig2.mysqlUser,
      password: runtimeConfig2.mysqlPassword,
      database: runtimeConfig2.mysqlDatabase
    });
    const edit = await con2.query(sql, data);
    con2.end();
    return true;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. users. ${error}`;
  }
});

const writeOrderToUser$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: writeOrderToUser
});

const createUserForVerificationEmail = defineEventHandler(async (event) => {
  const user = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const token = `${randomInteger(0, 9)}${randomInteger(0, 9)}${randomInteger(0, 9)}${randomInteger(
    0,
    9
  )}`;
  console.log("token:", token);
  try {
    const [rows] = await con.execute(
      `select * from usersNoVerificatedEmail WHERE email='${user.email.input}'`
    );
    let data = [];
    let sql = ``;
    if (!rows[0]) {
      data = [user.email.input, user.name.input, user.phone.input, user.pass.input, token];
      sql = `INSERT INTO usersNoVerificatedEmail SET email=?, name=?, phone=?, password=?, token=?`;
    } else {
      data = [user.name.input, user.phone.input, user.pass.input, token];
      sql = `UPDATE usersNoVerificatedEmail SET name=?, phone=?, password=?, token=? WHERE email='${user.email.input}'`;
    }
    const add = await con.query(sql, data);
    con.end();
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. usersNoVerificatedEmail. ${error}`;
  }
  const sendMailVerification = await $fetch("/api/auth/sendMailVerification", {
    method: "POST",
    body: { email: user.email.input, token }
  });
  return sendMailVerification;
});
function randomInteger(min, max) {
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
}

const createUserForVerificationEmail$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: createUserForVerificationEmail
});

const hello = defineEventHandler((event) => {
  return `\u041F\u043E\u043B\u044F \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u0430\u043B\u0435\u0435...`;
});

const hello$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: hello
});

const loadSleep = defineEventHandler((event) => {
  const qq = {
    api: "hello",
    query: getQuery(event)
  };
  return sleep(qq);
});

const loadSleep$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: loadSleep
});

const sendMail = defineEventHandler((event) => {
  const runtimeConfig = useRuntimeConfig();
  async function main() {
    await nodemailer.createTestAccount();
    let transporter = nodemailer.createTransport({
      host: runtimeConfig.emailHost,
      port: runtimeConfig.emailPort,
      secure: runtimeConfig.emailSecure,
      // true for 465, false for other ports
      auth: {
        user: runtimeConfig.emailUser,
        // generated ethereal user
        pass: runtimeConfig.emailPass
        // generated ethereal password
      }
    });
    let info = await transporter.sendMail({
      from: '"Fred Foo \u{1F47B}" <admin@serega183.ru>',
      // sender address
      to: "serega183@mail.ru",
      // list of receivers
      subject: "Hello \u2714",
      // Subject line
      text: `Hello world?`,
      // plain text body
      html: "<b>Hello world?</b>"
      // html body
    });
    console.log("Message sent: %s", info.messageId);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  }
  main().catch(console.error);
});

const sendMail$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: sendMail
});

const testApiDalee = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["name"] !== "undefined") {
    fields.name.needValidate = {
      isEmpty: true,
      minLength: 5
    };
  }
  if (typeof fields["age"] !== "undefined") {
    fields.age.needValidate = {
      isEmpty: true,
      digit: true,
      minLength: 5
    };
  }
  const validateFields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validateFields instanceof Object) {
    return validateFields;
  } else {
    if (write) {
      return await $fetch("/api/test/hello?qqq=123");
    }
    return validateFields;
  }
});

const testApiDalee$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: testApiDalee
});

const validateFieldsRules = defineEventHandler(async (event) => {
  const { fields } = await readBody(event);
  const errorsFields = {};
  for (const field in fields) {
    errorsFields[field] = [];
    if (!fields[field].needValidate)
      continue;
    const needValidate = fields[field].needValidate;
    if (needValidate.minLength) {
      if (minLength(fields[field].input, fields[field].needValidate.minLength) !== true) {
        errorsFields[field].push(
          minLength(fields[field].input, fields[field].needValidate.minLength)
        );
      }
    }
    if (needValidate.isEmpty) {
      if (isEmpty(fields[field].input) !== true) {
        errorsFields[field].push(isEmpty(fields[field].input));
      }
    }
    if (needValidate.isDigit) {
      if (isDigit(fields[field].input) !== true) {
        errorsFields[field].push(isDigit(fields[field].input));
      }
    }
    if (needValidate.isStock) {
      if (isStock(fields[field].input) !== true) {
        errorsFields[field].push(isStock(fields[field].input));
      }
    }
    if (needValidate.isRating) {
      if (isRating(fields[field].input) !== true) {
        errorsFields[field].push(isRating(fields[field].input));
      }
    }
    if (needValidate.isCheckCategory) {
      if (isCheckCategory(fields[field].input) !== true) {
        errorsFields[field].push(isCheckCategory(fields[field].input));
      }
    }
    if (needValidate.isPhone) {
      if (isPhone(fields[field].input) !== true) {
        errorsFields[field].push(isPhone(fields[field].input));
      }
    }
    if (needValidate.isEmail) {
      if (isEmail(fields[field].input) !== true) {
        errorsFields[field].push(isEmail(fields[field].input));
      }
    }
  }
  const errFields = {};
  for (const field in errorsFields) {
    if (errorsFields[field].length > 0) {
      errFields[field] = errorsFields[field];
    }
  }
  return Object.keys(errFields).length ? errFields : `\u0412\u0441\u0435 \u043F\u043E\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u044B \u0432\u0435\u0440\u043D\u043E`;
});
const minLength = (input, length) => {
  if (input.length < length) {
    return `\u0422\u0435\u043A\u0441\u0442 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043D\u0435 \u043C\u0435\u043D\u0435\u0435 ${length} \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432`;
  }
  return true;
};
function isEmpty(input) {
  if (input.length == 0) {
    return `\u041F\u0443\u0441\u0442\u043E\u0435 \u043F\u043E\u043B\u0435 \u043D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E`;
  }
  return true;
}
function isDigit(input) {
  if (Number.isNaN(Number(input))) {
    return `\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043B\u043E\u0435 \u0447\u0438\u0441\u043B\u043E`;
  }
  return true;
}
function isStock(input) {
  if (input != 1 && input != 0) {
    return `0 - \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0440\u0430\u0441\u043F\u0440\u043E\u0434\u0430\u0436\u0443, 1 - \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0440\u0430\u0441\u043F\u0440\u043E\u0434\u0430\u0436\u0443`;
  }
  return true;
}
function isRating(input) {
  if (input > 10 || input < 0) {
    return `\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0447\u0438\u0441\u043B\u043E \u043E\u0442 0 \u0434\u043E 10`;
  }
  return true;
}
function isCheckCategory(input) {
  if (input.length == 0) {
    return `\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438(\u0438/\u044E)`;
  }
  return true;
}
function isPhone(input) {
  if (input[0] != 8) {
    return "\u041D\u043E\u043C\u0435\u0440 \u0434\u043E\u043B\u0436\u0435\u043D \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 8";
  }
  if (Number.isNaN(Number(input))) {
    return "\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0446\u0438\u0444\u0440\u044B";
  }
  if (input.length != 11) {
    return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 11 \u0446\u0438\u0444\u0440";
  }
  return true;
}
function isEmail(input) {
  const EMAIL_REGEXP = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/iu;
  if (!EMAIL_REGEXP.test(input)) {
    return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043A\u043E\u0440\u0435\u043A\u0442\u043D\u044B\u0439 email";
  }
  return true;
}

const validateFieldsRules$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: validateFieldsRules
});

const appRootId = "__nuxt";

const appRootTag = "div";

globalThis.__buildAssetsURL = buildAssetsURL;
globalThis.__publicAssetsURL = publicAssetsURL;
const getClientManifest = () => import('/app/.nuxt/dist/server/client.manifest.mjs').then((r) => r.default || r).then((r) => typeof r === "function" ? r() : r);
const getStaticRenderedHead = () => Promise.resolve().then(function () { return _virtual__headStatic$1; }).then((r) => r.default || r);
const getServerEntry = () => import('/app/.nuxt/dist/server/server.mjs').then((r) => r.default || r);
const getSSRRenderer = lazyCachedFunction(async () => {
  const manifest = await getClientManifest();
  if (!manifest) {
    throw new Error("client.manifest is not available");
  }
  const createSSRApp = await getServerEntry();
  if (!createSSRApp) {
    throw new Error("Server bundle is not available");
  }
  const options = {
    manifest,
    renderToString: renderToString$1,
    buildAssetsURL
  };
  const renderer = createRenderer(createSSRApp, options);
  async function renderToString$1(input, context) {
    const html = await renderToString(input, context);
    if (process.env.NUXT_VITE_NODE_OPTIONS) {
      renderer.rendererContext.updateManifest(await getClientManifest());
    }
    return `<${appRootTag} id="${appRootId}">${html}</${appRootTag}>`;
  }
  return renderer;
});
const getSPARenderer = lazyCachedFunction(async () => {
  const manifest = await getClientManifest();
  const options = {
    manifest,
    renderToString: () => `<${appRootTag} id="${appRootId}"></${appRootTag}>`,
    buildAssetsURL
  };
  const renderer = createRenderer(() => () => {
  }, options);
  const result = await renderer.renderToString({});
  const renderToString = (ssrContext) => {
    const config = useRuntimeConfig();
    ssrContext.payload = {
      _errors: {},
      serverRendered: false,
      data: {},
      state: {}
    };
    ssrContext.config = {
      public: config.public,
      app: config.app
    };
    ssrContext.renderMeta = ssrContext.renderMeta ?? getStaticRenderedHead;
    return Promise.resolve(result);
  };
  return {
    rendererContext: renderer.rendererContext,
    renderToString
  };
});
const PAYLOAD_URL_RE = /\/_payload(\.[a-zA-Z0-9]+)?.js(\?.*)?$/;
const renderer = defineRenderHandler(async (event) => {
  const nitroApp = useNitroApp();
  const ssrError = event.node.req.url?.startsWith("/__nuxt_error") ? getQuery(event) : null;
  if (ssrError && ssrError.statusCode) {
    ssrError.statusCode = parseInt(ssrError.statusCode);
  }
  if (ssrError && event.node.req.socket.readyState !== "readOnly") {
    throw createError("Cannot directly render error page!");
  }
  const islandContext = void 0;
  let url = ssrError?.url || islandContext?.url || event.node.req.url;
  const isRenderingPayload = PAYLOAD_URL_RE.test(url);
  if (isRenderingPayload) {
    url = url.substring(0, url.lastIndexOf("/")) || "/";
    event.node.req.url = url;
  }
  const routeOptions = getRouteRules(event);
  const ssrContext = {
    url,
    event,
    runtimeConfig: useRuntimeConfig(),
    noSSR: event.context.nuxt?.noSSR || routeOptions.ssr === false || (false),
    error: !!ssrError,
    nuxt: void 0,
    /* NuxtApp */
    payload: ssrError ? { error: ssrError } : {},
    _payloadReducers: {},
    islandContext
  };
  const renderer = ssrContext.noSSR ? await getSPARenderer() : await getSSRRenderer();
  const _rendered = await renderer.renderToString(ssrContext).catch((error) => {
    throw !ssrError && ssrContext.payload?.error || error;
  });
  await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext });
  if (event.node.res.headersSent || event.node.res.writableEnded) {
    return;
  }
  if (ssrContext.payload?.error && !ssrError) {
    throw ssrContext.payload.error;
  }
  if (isRenderingPayload) {
    const response2 = renderPayloadResponse(ssrContext);
    return response2;
  }
  const renderedMeta = await ssrContext.renderMeta?.() ?? {};
  const inlinedStyles = "";
  const NO_SCRIPTS = routeOptions.experimentalNoScripts;
  const htmlContext = {
    island: Boolean(islandContext),
    htmlAttrs: normalizeChunks([renderedMeta.htmlAttrs]),
    head: normalizeChunks([
      renderedMeta.headTags,
      null,
      NO_SCRIPTS ? null : _rendered.renderResourceHints(),
      _rendered.renderStyles(),
      inlinedStyles,
      ssrContext.styles
    ]),
    bodyAttrs: normalizeChunks([renderedMeta.bodyAttrs]),
    bodyPrepend: normalizeChunks([
      renderedMeta.bodyScriptsPrepend,
      ssrContext.teleports?.body
    ]),
    body: [_rendered.html],
    bodyAppend: normalizeChunks([
      NO_SCRIPTS ? void 0 : renderPayloadScript({ ssrContext, data: ssrContext.payload }),
      routeOptions.experimentalNoScripts ? void 0 : _rendered.renderScripts(),
      // Note: bodyScripts may contain tags other than <script>
      renderedMeta.bodyScripts
    ])
  };
  await nitroApp.hooks.callHook("render:html", htmlContext, { event });
  const response = {
    body: renderHTMLDocument(htmlContext),
    statusCode: event.node.res.statusCode,
    statusMessage: event.node.res.statusMessage,
    headers: {
      "content-type": "text/html;charset=utf-8",
      "x-powered-by": "Nuxt"
    }
  };
  return response;
});
function lazyCachedFunction(fn) {
  let res = null;
  return () => {
    if (res === null) {
      res = fn().catch((err) => {
        res = null;
        throw err;
      });
    }
    return res;
  };
}
function normalizeChunks(chunks) {
  return chunks.filter(Boolean).map((i) => i.trim());
}
function joinTags(tags) {
  return tags.join("");
}
function joinAttrs(chunks) {
  return chunks.join(" ");
}
function renderHTMLDocument(html) {
  return `<!DOCTYPE html>
<html ${joinAttrs(html.htmlAttrs)}>
<head>${joinTags(html.head)}</head>
<body ${joinAttrs(html.bodyAttrs)}>${joinTags(html.bodyPrepend)}${joinTags(html.body)}${joinTags(html.bodyAppend)}</body>
</html>`;
}
function renderPayloadResponse(ssrContext) {
  return {
    body: `export default ${devalue(splitPayload(ssrContext).payload)}`,
    statusCode: ssrContext.event.node.res.statusCode,
    statusMessage: ssrContext.event.node.res.statusMessage,
    headers: {
      "content-type": "text/javascript;charset=utf-8",
      "x-powered-by": "Nuxt"
    }
  };
}
function renderPayloadScript(opts) {
  opts.data.config = opts.ssrContext.config;
  return `<script>window.__NUXT__=${devalue(opts.data)}<\/script>`;
}
function splitPayload(ssrContext) {
  const { data, prerenderedAt, ...initial } = ssrContext.payload;
  return {
    initial: { ...initial, prerenderedAt },
    payload: { data, prerenderedAt }
  };
}

const renderer$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: renderer
});

const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<link rel=\"icon\" type=\"image/x-icon\" href=\"/icons/logo3.png\">\n<link rel=\"stylesheet\" href=\"/main.css\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

const _virtual__headStatic$1 = /*#__PURE__*/Object.freeze({
      __proto__: null,
      default: _virtual__headStatic
});
//# sourceMappingURL=index.mjs.map
