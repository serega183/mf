//const storeCart = usePiniaCart();
export async function composablesLog() {
  console.log("nuxt/composables/log.js");
  // console.log(from);
  //  console.log(to.path);
}
