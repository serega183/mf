import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const sendTokenForMailConfirm = defineEventHandler(async (event) => {
  const { token, email } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  try {
    const data = [token];
    const sql = `select * from usersNoVerificatedEmail WHERE email='${email}'`;
    const [rows] = await con.execute(sql);
    if (rows[0].token == token) {
      const user = [rows[0].name, rows[0].phone, rows[0].email, rows[0].password];
      const sql2 = `INSERT INTO users SET name=?, phone=?, email=?, password=?`;
      const doblUser = await $fetch("/api/db_users/userDuplicateFind", {
        method: "POST",
        body: { email: rows[0].email }
      });
      if (doblUser) {
        con.query(`DELETE FROM users WHERE email='${rows[0].email}'`);
      }
      const add = con.query(sql2, user);
      con.query(`DELETE FROM usersNoVerificatedEmail WHERE email='${rows[0].email}'`);
      con.end();
      return true;
    } else if (rows[0].try > 0) {
      con.execute(
        `UPDATE usersNoVerificatedEmail SET try = try - 1 WHERE email='${rows[0].email}'`
      );
      con.end();
      return false;
    } else {
      return "resend";
    }
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. usersNoVerificatedEmail. ${error}`;
  }
});

export { sendTokenForMailConfirm as default };
//# sourceMappingURL=sendTokenForMailConfirm.mjs.map
