import { defineEventHandler, getQuery } from 'h3';

const loadSleep = defineEventHandler((event) => {
  const qq = {
    api: "hello",
    query: getQuery(event)
  };
  return sleep(qq);
});

export { loadSleep as default };
//# sourceMappingURL=loadSleep.mjs.map
