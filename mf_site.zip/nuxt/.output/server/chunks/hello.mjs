import { defineEventHandler } from 'h3';

const hello = defineEventHandler((event) => {
  return `\u041F\u043E\u043B\u044F \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u0430\u043B\u0435\u0435...`;
});

export { hello as default };
//# sourceMappingURL=hello.mjs.map
