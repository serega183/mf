import { defineEventHandler, readBody } from 'h3';
import nodemailer from 'nodemailer';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const sendMailVerification = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const { email, token } = await readBody(event);
  async function main() {
    let transporter = nodemailer.createTransport({
      host: runtimeConfig.emailHost,
      port: runtimeConfig.emailPort,
      secure: runtimeConfig.emailSecure,
      // true for 465, false for other ports
      auth: {
        user: runtimeConfig.emailUser,
        // generated ethereal user
        pass: runtimeConfig.emailPass
        // generated ethereal password
      }
    });
    await transporter.sendMail({
      from: `${runtimeConfig.appName} <admin@serega183.ru>`,
      // sender address
      to: email,
      // list of receivers
      subject: `${runtimeConfig.appName} \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F`,
      // Subject line
      text: token,
      // plain text body
      html: `<b>\u041A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F: ${token}</b>`
      // html body
    }).catch((err) => {
      return { err };
    });
    return true;
  }
  return main();
});

export { sendMailVerification as default };
//# sourceMappingURL=sendMailVerification.mjs.map
