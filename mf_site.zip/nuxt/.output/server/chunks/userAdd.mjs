import { defineEventHandler, readBody } from 'h3';

const userAdd = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["name"] !== "undefined") {
    fields.name.needValidate = {
      isEmpty: true
    };
  }
  if (typeof fields["phone"] !== "undefined") {
    fields.phone.needValidate = {
      isPhone: true
    };
  }
  if (typeof fields["email"] !== "undefined") {
    fields.email.needValidate = {
      isEmail: true
    };
  }
  if (typeof fields["pass"] !== "undefined") {
    fields.pass.needValidate = {
      isEmpty: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const doblMail = await $fetch("/api/db_users/userDuplicateFind", {
        method: "POST",
        body: { email: fields.email.input }
      });
      if (doblMail) {
        return { email: ["\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0441 \u0442\u0430\u043A\u0438\u043C email \u0443\u0436\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D"] };
      }
      const createUserForVerificationEmail = await $fetch(
        "/api/db_usersNoVerificatedEmail/createUserForVerificationEmail",
        {
          method: "POST",
          body: fields
        }
      );
      return createUserForVerificationEmail;
    }
    return validatefields;
  }
});

export { userAdd as default };
//# sourceMappingURL=userAdd.mjs.map
