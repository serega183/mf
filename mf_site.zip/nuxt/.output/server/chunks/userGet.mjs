import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const userGet = defineEventHandler(async (event) => {
  const { email } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  try {
    const [rows] = await con.execute(`select * from users WHERE email='${email}'`);
    con.end();
    return rows[0] ? rows[0] : false;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. login. ${error}`;
  }
});

export { userGet as default };
//# sourceMappingURL=userGet.mjs.map
