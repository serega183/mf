import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const writeOrderToUser = defineEventHandler(async (event) => {
  const { email, id } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  let [ord] = await con.execute(`SELECT orders_id FROM users WHERE email='${email}'`);
  if (!ord[0].orders_id) {
    ord[0].orders_id = [id];
  } else {
    ord[0].orders_id.push(id);
  }
  const orders = ord[0].orders_id;
  const data = [JSON.stringify(orders)];
  const sql = `UPDATE users SET orders_id=? WHERE email='${email}'`;
  try {
    const runtimeConfig2 = useRuntimeConfig();
    const con2 = await mysql.createConnection({
      host: runtimeConfig2.mysqlHost,
      port: runtimeConfig2.mysqlPort,
      user: runtimeConfig2.mysqlUser,
      password: runtimeConfig2.mysqlPassword,
      database: runtimeConfig2.mysqlDatabase
    });
    const edit = await con2.query(sql, data);
    con2.end();
    return true;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. users. ${error}`;
  }
});

export { writeOrderToUser as default };
//# sourceMappingURL=writeOrderToUser.mjs.map
