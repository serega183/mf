import { defineEventHandler } from 'h3';

const categoriesAskAll_copy = defineEventHandler(async (event) => {
  const [rows] = await event.context.db_mf_mysql_01.execute("select * from categories");
  return rows;
});

export { categoriesAskAll_copy as default };
//# sourceMappingURL=categoriesAskAll copy.mjs.map
