import { defineEventHandler, readBody } from 'h3';
import nodemailer from 'nodemailer';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const sendPass = defineEventHandler(async (event) => {
  useRuntimeConfig();
  const { fields, write } = await readBody(event);
  if (typeof fields["email"] !== "undefined") {
    fields.email.needValidate = {
      isEmail: true
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const user = await $fetch("/api/db_users/userGet", {
        method: "POST",
        body: { email: fields.email.input }
      });
      if (user) {
        return await sendMail(user.email, user.password);
      } else {
        return { user: false };
      }
    }
    return validatefields;
  }
});
async function sendMail(email, pass) {
  const runtimeConfig = useRuntimeConfig();
  let transporter = nodemailer.createTransport({
    host: runtimeConfig.emailHost,
    port: runtimeConfig.emailPort,
    secure: runtimeConfig.emailSecure,
    // true for 465, false for other ports
    auth: {
      user: runtimeConfig.emailUser,
      // generated ethereal user
      pass: runtimeConfig.emailPass
      // generated ethereal password
    }
  });
  await transporter.sendMail({
    from: `${runtimeConfig.appName} <admin@serega183.ru>`,
    // sender address
    to: email,
    // list of receivers
    subject: `${runtimeConfig.appName} \u0412\u0430\u0448 \u043F\u0430\u0440\u043E\u043B\u044C`,
    // Subject line
    text: pass,
    // plain text body
    html: `<b>\u041F\u0430\u0440\u043E\u043B\u044C: ${pass}</b>`
    // html body
  }).catch((err) => {
    return { err };
  });
  return true;
}

export { sendPass as default };
//# sourceMappingURL=sendPass.mjs.map
