import { u as useSeoMeta, f as usePiniaCart, _ as __nuxt_component_0 } from '../server.mjs';
import { unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "cart",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: `\u041A\u043E\u0440\u0437\u0438\u043D\u0430`
    });
    const storeCart = usePiniaCart();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      if (Object.keys(unref(storeCart).cart).length) {
        _push(`<div${ssrRenderAttrs(_attrs)}> \u041A\u043E\u0440\u0437\u0438\u043D\u0430: <!--[-->`);
        ssrRenderList(unref(storeCart).cart, (cnt, id) => {
          _push(`<div> id:${ssrInterpolate(id)}, count:${ssrInterpolate(cnt)} <br> <button>removeFromCart</button><button>plusCount</button>`);
          if (unref(storeCart).cart[id].count > 1) {
            _push(`<button>minusCount</button>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<hr></div>`);
        });
        _push(`<!--]-->`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/site/user/making-order" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u041E\u0444\u043E\u0440\u043C\u0438\u0442\u044C`);
            } else {
              return [
                createTextVNode("\u041E\u0444\u043E\u0440\u043C\u0438\u0442\u044C")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div${ssrRenderAttrs(_attrs)}>\u041A\u043E\u0440\u0437\u0438\u043D\u0430 \u043F\u0443\u0441\u0442\u0430</div>`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/user/cart.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=cart-6c9b437e.mjs.map
