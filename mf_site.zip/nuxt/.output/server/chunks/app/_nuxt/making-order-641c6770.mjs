import { _ as __nuxt_component_0 } from './textField-086dd2ad.mjs';
import { u as useSeoMeta, f as usePiniaCart } from '../server.mjs';
import { ref, unref, useSSRContext } from 'vue';
import { m as myCompValidate } from './myCompValidate-4ab9fb1a.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './fetch-fbd89f81.mjs';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "making-order",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: `\u041E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435`
    });
    const storeCart = usePiniaCart();
    const userData = ref({
      name: "",
      phone: "",
      street: "",
      house: "",
      apartment: "",
      comment: ""
    });
    let errFields = ref({});
    async function testFF(write, fieldKey) {
      const apiDalee = "/api/db_orders/writeOrder";
      const fields = ref({});
      if (fieldKey) {
        fields.value[fieldKey] = userData.value[fieldKey];
        errFields.value[fieldKey] = (await myCompValidate(apiDalee, fields, write))[fieldKey];
      } else {
        fields.value = userData.value;
        errFields.value = await myCompValidate(apiDalee, fields, write, storeCart.cart, curDateTime());
      }
      if (await errFields.value === true) {
        console.log("\u0432\u0441\u0451 \u043E\u043A");
      }
      localStorage.setItem("userData", JSON.stringify(userData.value));
    }
    function curDateTime() {
      const date = /* @__PURE__ */ new Date();
      const g = date.getFullYear();
      let m = (Number(date.getMonth()) + 1).toString();
      let d = Number(date.getDate()).toString();
      let h = Number(date.getHours()).toString();
      let mn = Number(date.getMinutes()).toString();
      if (m.length < 2) {
        m = `0${m}`;
      }
      if (d.length < 2) {
        d = `0${d}`;
      }
      if (h.length < 2) {
        h = `0${h}`;
      }
      if (mn.length < 2) {
        mn = `0${mn}`;
      }
      return { date: `${g}-${m}-${d}`, time: `${h}:${mn}` };
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_userTextField = __nuxt_component_0;
      _push(`<!--[--><h4> \u041E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 </h4>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "name",
        text: unref(userData).name,
        err: unref(errFields),
        placeholder: "\u0418\u043C\u044F",
        onUpdate: ($event) => {
          unref(userData).name = $event;
          testFF(false, "name");
        }
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "phone",
        text: unref(userData).phone,
        err: unref(errFields),
        placeholder: "\u0422\u0435\u043B\u0435\u0444\u043E\u043D",
        onUpdate: ($event) => {
          unref(userData).phone = $event;
          testFF(false, "phone");
        }
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "street",
        text: unref(userData).street,
        err: unref(errFields),
        placeholder: "\u0423\u043B\u0438\u0446\u0430",
        onUpdate: ($event) => {
          unref(userData).street = $event;
          testFF(false, "street");
        }
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "house",
        text: unref(userData).house,
        err: unref(errFields),
        placeholder: "\u0414\u043E\u043C",
        onUpdate: ($event) => {
          unref(userData).house = $event;
          testFF(false, "house");
        }
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "apartment",
        text: unref(userData).apartment,
        err: unref(errFields),
        placeholder: "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430",
        onUpdate: ($event) => {
          unref(userData).apartment = $event;
          testFF(false, "apartment");
        }
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "comment",
        text: unref(userData).comment,
        err: unref(errFields),
        placeholder: "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439",
        onUpdate: ($event) => {
          unref(userData).comment = $event;
          testFF(false, "comment");
        }
      }, null, _parent));
      _push(`<hr><button>writeOrder</button><br><br><br> \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: ${ssrInterpolate(unref(errFields))}<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/user/making-order.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=making-order-641c6770.mjs.map
