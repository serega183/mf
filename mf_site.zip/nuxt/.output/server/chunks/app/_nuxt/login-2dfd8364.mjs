import { _ as __nuxt_component_0 } from './textField-086dd2ad.mjs';
import { a as useRoute, u as useSeoMeta, d as useAuth, _ as __nuxt_component_0$1 } from '../server.mjs';
import { ref, unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    useSeoMeta({
      title: `Login`
    });
    useAuth();
    let err = ref(false);
    const user = ref({
      email: "",
      pass: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_userTextField = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "email",
        text: unref(user).email,
        placeholder: "email",
        onUpdate: ($event) => unref(user).email = $event
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "pass",
        text: unref(user).pass,
        placeholder: "\u041F\u0430\u0440\u043E\u043B\u044C",
        onUpdate: ($event) => unref(user).pass = $event
      }, null, _parent));
      _push(`<button>\u0412\u043E\u0439\u0442\u0438</button>`);
      if (unref(err)) {
        _push(`<p>${ssrInterpolate(unref(err))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/site/user/auth/registration" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F`);
          } else {
            return [
              createTextVNode("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` | `);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/site/user/auth/forgot-pass" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0417\u0430\u0431\u044B\u043B \u043F\u0430\u0440\u043E\u043B\u044C?`);
          } else {
            return [
              createTextVNode("\u0417\u0430\u0431\u044B\u043B \u043F\u0430\u0440\u043E\u043B\u044C?")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/user/auth/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login-2dfd8364.mjs.map
