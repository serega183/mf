import { _ as __nuxt_component_0 } from './findProduct-2777c939.mjs';
import { ref, withAsyncContext, unref, useSSRContext } from 'vue';
import { b as useRouter, u as useSeoMeta } from '../server.mjs';
import { a as useLazyAsyncData } from './asyncData-b6294b3f.mjs';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    useSeoMeta({
      title: "\u041A\u0430\u0442\u0430\u043B\u043E\u0433"
    });
    const findProduct = ref("\u041F\u0440\u043E");
    const { data: categories, pending, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useLazyAsyncData(
      "categories",
      () => $fetch("/api/db_categories/categoriesAskAll")
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_siteFindProduct = __nuxt_component_0;
      _push(`<!--[--><h2> product categories index </h2><hr>`);
      _push(ssrRenderComponent(_component_siteFindProduct, {
        nazv: "publicationdate",
        text: unref(findProduct),
        placeholder: "\u041F\u043E\u0438\u0441\u043A ...",
        onUpdate: ($event) => findProduct.value = $event
      }, null, _parent));
      _push(`<button>\u041F\u043E\u0438\u0441\u043A</button><hr><!--[-->`);
      ssrRenderList(unref(categories), (item, index) => {
        _push(`<div><span>${ssrInterpolate(index + 1)}</span><button><img${ssrRenderAttr("src", item.cat_img)} alt="">${ssrInterpolate(item.cat_name)}</button></div>`);
      });
      _push(`<!--]--><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-a0d438a1.mjs.map
