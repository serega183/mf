import { _ as __nuxt_component_0 } from './textField-086dd2ad.mjs';
import { u as useSeoMeta, n as navigateTo } from '../server.mjs';
import { ref, unref, useSSRContext } from 'vue';
import { m as myCompValidate } from './myCompValidate-4ab9fb1a.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './fetch-fbd89f81.mjs';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "registration",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: "\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F"
    });
    const user = ref({
      name: "\u0418\u043C\u044F\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430",
      email: "serega183@mail.ru",
      phone: "89600160061",
      pass: "qqq"
    });
    let errFields = ref({});
    const pending = ref(false);
    async function testFF(write, fieldKey) {
      pending.value = true;
      const resp = ref({});
      const apiDalee = "/api/db_users/userAdd";
      const fields = ref({});
      if (fieldKey) {
        fields.value[fieldKey] = user.value[fieldKey];
        resp.value[fieldKey] = (await myCompValidate(apiDalee, fields, write))[fieldKey];
      } else {
        fields.value = user.value;
        sessionStorage.setItem("user", JSON.stringify(user.value));
        resp.value = await myCompValidate(apiDalee, fields, write);
      }
      if (await resp.value === true) {
        console.log("\u0412\u0441\u0451 \u043E\u043A");
        navigateTo({
          path: "/site/user/auth/confirmUserRegistration"
        });
      }
      if (errFields.value) {
        pending.value = false;
      }
      errFields.value = resp.value;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_userTextField = __nuxt_component_0;
      _push(`<!--[--><h2> \u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F </h2><hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "name",
        text: unref(user).name,
        err: unref(errFields),
        placeholder: "\u041B\u043E\u0433\u0438\u043D",
        onUpdate: ($event) => (unref(user).name = $event, testFF(false, "name"))
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "email",
        text: unref(user).email,
        err: unref(errFields),
        placeholder: "Email",
        onUpdate: ($event) => (unref(user).email = $event, testFF(false, "email"))
      }, null, _parent));
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "phone",
        text: unref(user).phone,
        err: unref(errFields),
        placeholder: "\u0422\u0435\u043B\u0435\u0444\u043E\u043D",
        onUpdate: ($event) => (unref(user).phone = $event, testFF(false, "phone"))
      }, null, _parent));
      _push(ssrRenderComponent(_component_userTextField, {
        nazv: "pass",
        text: unref(user).pass,
        err: unref(errFields),
        placeholder: "\u041F\u0430\u0440\u043E\u043B\u044C",
        onUpdate: ($event) => (unref(user).pass = $event, testFF(false, "pass"))
      }, null, _parent));
      _push(`<br>`);
      if (!unref(pending)) {
        _push(`<button>\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F</button>`);
      } else {
        _push(`<button disabled>\u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0430...</button>`);
      }
      _push(`<br><hr> errFields: ${ssrInterpolate(unref(errFields))} <hr> pending: ${ssrInterpolate(unref(pending))} <hr><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/user/auth/registration.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=registration-e3e45f61.mjs.map
