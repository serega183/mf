import { u as useSeoMeta } from '../server.mjs';
import { ref, computed, withAsyncContext, unref, isRef, useSSRContext } from 'vue';
import { u as useLazyFetch } from './fetch-fbd89f81.mjs';
import { o as onlyForAdmin } from './onlyForAdmin-250922f8.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import VueDatePicker from '@vuepic/vue-datepicker';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "db-orders",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useSeoMeta({
      title: `\u0417\u0430\u043A\u0430\u0437\u044B`
    });
    const dateOt = ref(/* @__PURE__ */ new Date());
    const dateDo = ref(/* @__PURE__ */ new Date());
    let curDateTime = ref({
      ot: computed(() => {
        const g = dateOt.value.getFullYear();
        let m = (Number(dateOt.value.getMonth()) + 1).toString();
        let d = Number(dateOt.value.getDate()).toString();
        if (m.length < 2) {
          m = `0${m}`;
        }
        if (d.length < 2) {
          d = `0${d}`;
        }
        return `${g}-${m}-${d}`;
      }),
      do: computed(() => {
        const g = dateDo.value.getFullYear();
        let m = (Number(dateDo.value.getMonth()) + 1).toString();
        let d = Number(dateDo.value.getDate()).toString();
        if (m.length < 2) {
          m = `0${m}`;
        }
        if (d.length < 2) {
          d = `0${d}`;
        }
        return `${g}-${m}-${d}`;
      })
    });
    function format(date) {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      return `${day}-${month}-${year}`;
    }
    const filterStatus = ref("\u041D\u043E\u0432\u044B\u0439");
    const statuses = ref([
      { text: "\u0412\u0441\u0435", value: "\u0412\u0441\u0435" },
      { text: "\u041D\u043E\u0432\u044B\u0439", value: "\u041D\u043E\u0432\u044B\u0439" },
      { text: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435", value: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435" },
      { text: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D", value: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D" }
    ]);
    const status = ref([
      { text: "\u041D\u043E\u0432\u044B\u0439", value: "\u041D\u043E\u0432\u044B\u0439" },
      { text: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435", value: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435" },
      { text: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D", value: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D" }
    ]);
    const { data: orders, refresh: refreshOrders, pending } = ([__temp, __restore] = withAsyncContext(() => useLazyFetch("/api/db_orders/ordersAll", { method: "POST", body: { filterStatus, filterDate: curDateTime } }, "$dcM6Dpjt1G")), __temp = await __temp, __restore(), __temp);
    onlyForAdmin();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h4> db_orders admin </h4>`);
      _push(ssrRenderComponent(unref(VueDatePicker), {
        modelValue: unref(dateOt),
        "onUpdate:modelValue": ($event) => isRef(dateOt) ? dateOt.value = $event : null,
        format: format(unref(dateOt))
      }, null, _parent));
      _push(ssrRenderComponent(unref(VueDatePicker), {
        modelValue: unref(dateDo),
        "onUpdate:modelValue": ($event) => isRef(dateDo) ? dateDo.value = $event : null,
        format: format(unref(dateDo))
      }, null, _parent));
      _push(`<div div>${ssrInterpolate(unref(filterStatus))}</div><hr><span>status: </span><select select><!--[-->`);
      ssrRenderList(unref(statuses), (status2) => {
        _push(`<option${ssrRenderAttr("value", status2.value)}>${ssrInterpolate(status2.text)}</option>`);
      });
      _push(`<!--]--></select><hr>`);
      if (!unref(pending)) {
        _push(`<div>`);
        if (!unref(orders).err) {
          _push(`<ol><h4>\u0417\u0430\u043A\u0430\u0437\u043E\u0432: ${ssrInterpolate(Object.keys(unref(orders).resp).length)}</h4><!--[-->`);
          ssrRenderList(unref(orders).resp, (order) => {
            _push(`<li><hr><h4>id: ${ssrInterpolate(order.id)} : ${ssrInterpolate(order.status)} : ${ssrInterpolate(order.name)}</h4><b><p>${ssrInterpolate(Object.keys(order.cart).length)}</p></b> ${ssrInterpolate(order)} <ul><!--[-->`);
            ssrRenderList(order.cart, (product) => {
              _push(`<li>${ssrInterpolate(product)}</li>`);
            });
            _push(`<!--]--></ul><br><button>orderDell</button><br><select><!--[-->`);
            ssrRenderList(unref(status), (stat) => {
              _push(`<option${ssrRenderAttr("value", stat.value)}>${ssrInterpolate(stat.text)}</option>`);
            });
            _push(`<!--]--></select><hr></li>`);
          });
          _push(`<!--]--></ol>`);
        } else {
          _push(`<span>${ssrInterpolate(unref(orders).err)}</span>`);
        }
        _push(`</div>`);
      } else {
        _push(`<div>\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430...</div>`);
      }
      _push(`<br><hr><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/db-orders/db-orders.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=db-orders-2ea87fe3.mjs.map
