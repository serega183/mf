import { d as useAuth, f as usePiniaCart, _ as __nuxt_component_0$1 } from '../server.mjs';
import { unref, useSSRContext, mergeProps, withCtx, createTextVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createVNode } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderSlot, ssrRenderList } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main$1 = {
  __name: "Cart",
  __ssrInlineRender: true,
  setup(__props) {
    const storeCart = usePiniaCart();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      if (Object.keys(unref(storeCart).cart).length) {
        _push(ssrRenderComponent(_component_NuxtLink, mergeProps({ to: "/site/user/cart" }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u041A\u043E\u0440\u0437\u0438\u043D\u0430: <!--[-->`);
              ssrRenderList(unref(storeCart).cart, (item) => {
                _push2(`<div${_scopeId}> id: ${ssrInterpolate(item.product.id)}, name: ${ssrInterpolate(item.product.name)} - ${ssrInterpolate(item.count)} <hr${_scopeId}></div>`);
              });
              _push2(`<!--]-->`);
            } else {
              return [
                createTextVNode("\u041A\u043E\u0440\u0437\u0438\u043D\u0430: "),
                (openBlock(true), createBlock(Fragment, null, renderList(unref(storeCart).cart, (item) => {
                  return openBlock(), createBlock("div", null, [
                    createTextVNode(" id: " + toDisplayString(item.product.id) + ", name: " + toDisplayString(item.product.name) + " - " + toDisplayString(item.count) + " ", 1),
                    createVNode("hr")
                  ]);
                }), 256))
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<div${ssrRenderAttrs(_attrs)}>\u041A\u043E\u0440\u0437\u0438\u043D\u0430 \u043F\u0443\u0441\u0442\u0430</div>`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/user/Cart.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    const { status, data, signIn, signOut, getSession } = useAuth();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UserCart = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}><h4> status:${ssrInterpolate(unref(status))} <br> data: ${ssrInterpolate(unref(data))} <br></h4> default layouts <div>`);
      _push(ssrRenderComponent(_component_UserCart, null, null, _parent));
      _push(`</div><div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-840e7d2d.mjs.map
