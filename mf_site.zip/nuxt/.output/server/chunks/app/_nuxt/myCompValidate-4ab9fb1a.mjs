import { u as useLazyFetch } from './fetch-fbd89f81.mjs';

async function myCompValidate(apiDalee, testField, write, cart, date) {
  const fieldToValidate = {};
  for (const key in testField.value) {
    fieldToValidate[key] = { input: testField.value[key] };
  }
  const { data } = await useLazyFetch(apiDalee, {
    method: "POST",
    body: { fields: fieldToValidate, write, cart, date }
  }, "$j1r7GOuSKE");
  return data.value;
}

export { myCompValidate as m };
//# sourceMappingURL=myCompValidate-4ab9fb1a.mjs.map
