import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { useSSRContext } from 'vue';

const _sfc_main = {
  __name: "findProduct",
  __ssrInlineRender: true,
  props: ["text", "placeholder"],
  emits: ["update"],
  setup(__props, { emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h4>\u041F\u043E\u0438\u0441\u043A</h4><input class="&#39;_input&#39;"${ssrRenderAttr("value", __props.text)}${ssrRenderAttr("placeholder", __props.placeholder)} autocomplete="off"></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/site/findProduct.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=findProduct-2777c939.mjs.map
