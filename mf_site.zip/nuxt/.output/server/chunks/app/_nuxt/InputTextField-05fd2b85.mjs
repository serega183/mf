import { useSSRContext, computed, unref } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrRenderClass, ssrRenderAttr } from 'vue/server-renderer';

const _sfc_main = {
  __name: "InputTextField",
  __ssrInlineRender: true,
  props: ["text", "nazv", "err", "placeholder"],
  emits: ["update"],
  setup(__props, { emit }) {
    const props = __props;
    const error = computed(() => {
      if (props.err && props.err[props.nazv]) {
        return props.err[props.nazv];
      }
      return false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h4>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u044F: &quot;${ssrInterpolate(__props.nazv)}&quot; `);
      if (unref(error)) {
        _push(`<!--[-->`);
        ssrRenderList(unref(error), (err) => {
          _push(`<span style="${ssrRenderStyle({ "color": "red" })}">${ssrInterpolate(err)}, </span>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</h4><input class="${ssrRenderClass([unref(error) ? "errorClass" : "", "_input"])}"${ssrRenderAttr("value", __props.text)}${ssrRenderAttr("placeholder", __props.placeholder)} autocomplete="off"></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/admin/db/InputTextField.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=InputTextField-05fd2b85.mjs.map
