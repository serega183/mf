import { withAsyncContext, unref, useSSRContext } from 'vue';
import { a as useRoute, u as useSeoMeta } from '../server.mjs';
import { u as useLazyFetch } from './fetch-fbd89f81.mjs';
import { o as onlyForAdmin } from './onlyForAdmin-250922f8.mjs';
import { ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "[cat_name]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    useSeoMeta({
      title: route.params.cat_name
    });
    const { data: products, pending, refresh: refreshProducts } = ([__temp, __restore] = withAsyncContext(() => useLazyFetch("/api/db_products/productsInCategoryAsk", { method: "POST", body: { cat_name: route.params.cat_name } }, "$0hM1bfT4CS")), __temp = await __temp, __restore(), __temp);
    onlyForAdmin();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h4> admin products cat_name ${ssrInterpolate(unref(route).params.cat_name)}</h4>`);
      if (!unref(pending)) {
        _push(`<div><ol>`);
        if (unref(products).length) {
          _push(`<div><!--[-->`);
          ssrRenderList(unref(products), (product) => {
            _push(`<div><hr><div>${ssrInterpolate(product.name)}</div><img${ssrRenderAttr("src", product.image)} alt=""><span>product:${ssrInterpolate(product)} | </span><br><br> ${ssrInterpolate(product.id)} <button>\u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C</button> <button>\u0443\u0434\u0430\u043B\u0438\u0442\u044C</button><hr></div>`);
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<div>\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u043F\u0443\u0441\u0442\u0430</div>`);
        }
        _push(`</ol><hr></div>`);
      } else {
        _push(`<div>\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430...</div>`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/db-products/products/admin-prod-category/[cat_name].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_cat_name_-1276356a.mjs.map
