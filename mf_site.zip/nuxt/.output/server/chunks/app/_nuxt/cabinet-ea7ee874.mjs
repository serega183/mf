import { u as useSeoMeta, d as useAuth } from '../server.mjs';
import { unref, useSSRContext } from 'vue';
import { ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "cabinet",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: `\u041A\u0430\u0431\u0438\u043D\u0435\u0442`
    });
    const { status, data, signIn, signOut, getSession } = useAuth();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h4> cabinet </h4> status:${ssrInterpolate(unref(status))} <br> data: ${ssrInterpolate(unref(data))} <br><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/user/cabinet.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=cabinet-ea7ee874.mjs.map
