import { withAsyncContext, unref, useSSRContext } from 'vue';
import { a as useRoute, u as useSeoMeta } from '../server.mjs';
import { u as useLazyFetch } from './fetch-fbd89f81.mjs';
import { ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "[cat_name]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    useSeoMeta({
      title: route.params.cat_name
    });
    const { data: products, pending } = ([__temp, __restore] = withAsyncContext(() => useLazyFetch("/api/db_products/productsInCategoryAsk", { method: "POST", body: { cat_name: route.params.cat_name } }, "$NykB7FnhjE")), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h4> route.params: ${ssrInterpolate(unref(route).params)} : ${ssrInterpolate(unref(route).params.cat_name)}<br> products cat_name </h4>`);
      if (!unref(pending)) {
        _push(`<div><ol>`);
        {
          _push(`<!--[-->`);
          ssrRenderList(unref(products), (product, index) => {
            _push(`<div><hr><div>${ssrInterpolate(index + 1)}. ${ssrInterpolate(product.name)}</div><img${ssrRenderAttr("src", product.image)} alt=""><span>product:${ssrInterpolate(product)} | </span><br><br><button>addToCart</button><hr></div>`);
          });
          _push(`<!--]-->`);
        }
        _push(`</ol><hr></div>`);
      } else {
        _push(`<div>\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430...</div>`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/products-category/[cat_name].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_cat_name_-7f6e8436.mjs.map
