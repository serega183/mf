import { _ as __nuxt_component_0 } from './InputTextField-05fd2b85.mjs';
import { computed, withAsyncContext, ref, watch, unref, useSSRContext } from 'vue';
import { a as useRoute, u as useSeoMeta, n as navigateTo } from '../server.mjs';
import { a as useFetch } from './fetch-fbd89f81.mjs';
import { m as myCompValidate } from './myCompValidate-4ab9fb1a.mjs';
import { o as onlyForAdmin } from './onlyForAdmin-250922f8.mjs';
import { ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderComponent } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "add-product",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRoute();
    useSeoMeta({
      title: `\u0414\u043E\u0431. \u0442\u043E\u0432\u0430\u0440\u0430`
    });
    const allCategoriesName = computed(() => {
      if (!errorAllCategories.value)
        return allCategories.value.map(function(cat) {
          return cat.cat_name;
        });
    });
    const { data: allCategories, pending, error: errorAllCategories, refresh: refreshAllCategories } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/db_categories/categoriesAskAll", {
      method: "GET"
    }, "$4lZX3xv0Fd")), __temp = await __temp, __restore(), __temp);
    const checkedCategories = ref([]);
    watch(checkedCategories, (newX) => {
      testFF(false, "category");
    });
    const product = ref({
      name: ``,
      category: computed(() => {
        return checkedCategories.value.join(", ");
      }),
      edinic: `1`,
      units: ``,
      price: ``,
      balance: ``,
      stock: `0`,
      image: `/`,
      description: ``,
      rating: `0`,
      maker: ``,
      param1: ``,
      param2: ``,
      param3: ``,
      publicationdate: curDateTime().stringDataTime
    });
    function curDateTime() {
      const date = /* @__PURE__ */ new Date();
      const g = date.getFullYear();
      let m = (Number(date.getMonth()) + 1).toString();
      let d = Number(date.getDate()).toString();
      let h = Number(date.getHours()).toString();
      let mn = Number(date.getMinutes()).toString();
      if (m.length < 2) {
        m = `0${m}`;
      }
      if (d.length < 2) {
        d = `0${d}`;
      }
      if (h.length < 2) {
        h = `0${h}`;
      }
      if (mn.length < 2) {
        mn = `0${mn}`;
      }
      return { stringDataTime: `${g}.${m}.${d} / ${h}:${mn}`, numData: Number(`${g}${m}${d}`) };
    }
    let errFields = ref({});
    async function testFF(write, fieldKey) {
      const apiDalee = "/api/db_products/productAdd";
      const fields = ref({});
      if (fieldKey) {
        fields.value[fieldKey] = product.value[fieldKey];
        errFields.value[fieldKey] = (await myCompValidate(apiDalee, fields, write))[fieldKey];
      } else {
        fields.value = product.value;
        errFields.value = await myCompValidate(apiDalee, fields, write);
      }
      if (await errFields.value === true) {
        navigateTo({
          path: "/admin/db-products/products/admin-products"
        });
      }
    }
    onlyForAdmin();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_adminDbInputTextField = __nuxt_component_0;
      _push(`<!--[--><h4> admin add-product </h4> errorAllCategories: ${ssrInterpolate(unref(errorAllCategories) ? unref(errorAllCategories) : "\u043E\u0448\u0438\u0431\u043E\u043A \u043D\u0435\u0442")} <br><br><h4>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u044F: &quot;category&quot; `);
      if (unref(errFields).category) {
        _push(`<span><!--[-->`);
        ssrRenderList(unref(errFields).category, (err) => {
          _push(`<span style="${ssrRenderStyle({ "color": "red" })}">${ssrInterpolate(err)}, </span>`);
        });
        _push(`<!--]--></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</h4><!--[-->`);
      ssrRenderList(unref(allCategoriesName), (cat) => {
        _push(`<span><input type="checkbox"${ssrRenderAttr("id", cat)}${ssrRenderAttr("value", cat)}${ssrIncludeBooleanAttr(Array.isArray(unref(checkedCategories)) ? ssrLooseContain(unref(checkedCategories), cat) : unref(checkedCategories)) ? " checked" : ""}><label${ssrRenderAttr("for", cat)}>${ssrInterpolate(cat)}</label> | </span>`);
      });
      _push(`<!--]-->`);
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "name",
        text: unref(product).name,
        err: unref(errFields),
        placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
        onUpdate: ($event) => {
          unref(product).name = $event;
          testFF(false, "name");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "edinic",
        text: unref(product).edinic,
        err: unref(errFields),
        placeholder: "\u0415\u0434\u0438\u043D\u0438\u0446",
        onUpdate: ($event) => {
          unref(product).edinic = $event;
          testFF(false, "edinic");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "units",
        text: unref(product).units,
        err: unref(errFields),
        placeholder: "\u0415\u0434\u0438\u043D\u0438\u0446\u044B \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F (\u0433\u0440., \u0448\u0442, \u043F\u0430\u0440\u0430, \u0443\u043F. \u0438 \u0442.\u043F.)",
        onUpdate: ($event) => {
          unref(product).units = $event;
          testFF(false, "units");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "price",
        text: unref(product).price,
        err: unref(errFields),
        placeholder: "\u0426\u0435\u043D\u0430",
        onUpdate: ($event) => {
          unref(product).price = $event;
          testFF(false, "price");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "balance",
        text: unref(product).balance,
        err: unref(errFields),
        placeholder: "\u041E\u0441\u0442\u0430\u0442\u043E\u043A \u043D\u0430 \u0441\u043A\u043B\u0430\u0434\u0435",
        onUpdate: ($event) => {
          unref(product).balance = $event;
          testFF(false, "balance");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "stock",
        text: unref(product).stock,
        err: unref(errFields),
        placeholder: "\u0412\u0445\u043E\u0434\u0438\u0442 \u043B\u0438 \u0432 \u0430\u043A\u0446\u0438\u044E",
        onUpdate: ($event) => {
          unref(product).stock = $event;
          testFF(false, "stock");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "image",
        text: unref(product).image,
        err: unref(errFields),
        placeholder: "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435",
        onUpdate: ($event) => {
          unref(product).image = $event;
          testFF(false, "image");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "description",
        text: unref(product).description,
        err: unref(errFields),
        placeholder: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435",
        onUpdate: ($event) => {
          unref(product).description = $event;
          testFF(false, "description");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "rating",
        text: unref(product).rating,
        err: unref(errFields),
        placeholder: "\u0420\u0435\u0439\u0442\u0438\u043D\u0433",
        onUpdate: ($event) => {
          unref(product).rating = $event;
          testFF(false, "rating");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "maker",
        text: unref(product).maker,
        err: unref(errFields),
        placeholder: "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C",
        onUpdate: ($event) => {
          unref(product).maker = $event;
          testFF(false, "maker");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "param1",
        text: unref(product).param1,
        err: unref(errFields),
        placeholder: "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043B\u044C\u0442\u0440\u0430 \u21161",
        onUpdate: ($event) => {
          unref(product).param1 = $event;
          testFF(false, "param1");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "param2",
        text: unref(product).param2,
        err: unref(errFields),
        placeholder: "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043B\u044C\u0442\u0440\u0430 \u21162",
        onUpdate: ($event) => {
          unref(product).param2 = $event;
          testFF(false, "param2");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "param3",
        text: unref(product).param3,
        err: unref(errFields),
        placeholder: "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043B\u044C\u0442\u0440\u0430 \u21163",
        onUpdate: ($event) => {
          unref(product).param3 = $event;
          testFF(false, "param3");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "publicationdate",
        text: unref(product).publicationdate,
        err: unref(errFields),
        placeholder: "\u0414\u0430\u0442\u0430 \u043F\u043E\u0441\u0442\u0443\u043F\u043B\u0435\u043D\u0438\u044F",
        onUpdate: ($event) => {
          unref(product).publicationdate = $event;
          testFF(false, "publicationdate");
        }
      }, null, _parent));
      _push(`<button>writeProduct</button><br><span>\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: ${ssrInterpolate(unref(errFields))}</span><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/db-products/products/add-product.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-product-7104856e.mjs.map
