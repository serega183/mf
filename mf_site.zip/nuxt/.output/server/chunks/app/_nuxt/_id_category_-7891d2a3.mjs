import { _ as __nuxt_component_0 } from './InputTextField-05fd2b85.mjs';
import { withAsyncContext, ref, unref, useSSRContext } from 'vue';
import { a as useRoute, u as useSeoMeta, n as navigateTo } from '../server.mjs';
import { m as myCompValidate } from './myCompValidate-4ab9fb1a.mjs';
import { o as onlyForAdmin } from './onlyForAdmin-250922f8.mjs';
import { ssrInterpolate, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './fetch-fbd89f81.mjs';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "[id_category]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    useSeoMeta({
      title: "\u0420\u0435\u0434. \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044E"
    });
    const category = ([__temp, __restore] = withAsyncContext(() => $fetch("/api/db_categories/categoriesAskOne", { method: "GET", query: { id: route.params.id_category } })), __temp = await __temp, __restore(), __temp);
    let respEditCategory = ref("respEditCategory");
    let errorEditCategory = ref("errorEditCategory");
    let errFields = ref({});
    async function testFF(write, fieldKey) {
      const editedCategory = ref(await category);
      const apiDalee = "/api/db_categories/categoryEdit";
      const fields = ref({});
      if (fieldKey) {
        fields.value[fieldKey] = editedCategory.value[fieldKey];
        errFields.value[fieldKey] = (await myCompValidate(apiDalee, fields, write))[fieldKey];
      } else {
        fields.value = editedCategory.value;
        errFields.value = await myCompValidate(apiDalee, fields, write);
      }
      if (await errFields.value === true) {
        navigateTo({
          path: "/admin/db-products/categories/admin-categories"
        });
      }
    }
    onlyForAdmin();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_adminDbInputTextField = __nuxt_component_0;
      _push(`<!--[--><h4> admin edit_category <br></h4> errorEditCategory: ${ssrInterpolate(unref(errorEditCategory))} <br> respEditCategory: ${ssrInterpolate(unref(respEditCategory))} <br><img${ssrRenderAttr("src", unref(category).cat_img)} alt=""><p>id_cat:${ssrInterpolate(unref(category).id_cat)}</p>`);
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "cat_name",
        text: unref(category).cat_name,
        err: unref(errFields),
        placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438",
        onUpdate: ($event) => {
          unref(category).cat_name = $event;
          testFF(false, "cat_name");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "cat_discr",
        text: unref(category).cat_discr,
        err: unref(errFields),
        placeholder: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438",
        onUpdate: ($event) => {
          unref(category).cat_discr = $event;
          testFF(false, "cat_discr");
        }
      }, null, _parent));
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "cat_img",
        text: unref(category).cat_img,
        err: unref(errFields),
        placeholder: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438",
        onUpdate: ($event) => {
          unref(category).cat_img = $event;
          testFF(false, "cat_img");
        }
      }, null, _parent));
      _push(`<hr><button>writeCategory</button><br> \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: ${ssrInterpolate(unref(errFields))} <!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/db-products/categories/edit_category/[id_category].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_category_-7891d2a3.mjs.map
