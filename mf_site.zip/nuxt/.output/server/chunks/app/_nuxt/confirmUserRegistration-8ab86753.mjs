import { u as useSeoMeta } from '../server.mjs';
import { ref, unref, useSSRContext } from 'vue';
import { ssrRenderAttr, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "confirmUserRegistration",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: `\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 email`
    });
    let token = ref();
    const disabled = ref(true);
    const isHideInput = ref(false);
    const timeTimer = 5;
    const timer = ref(timeTimer);
    let resp = ref();
    ref(false);
    const pending = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h4> confirm </h4><p> \u041F\u0440\u043E\u0432\u0435\u0440\u044C \u043F\u043E\u0447\u0442\u0443 \u0442\u0430\u043C \u0446\u0438\u0444\u0440\u044B. \u0412\u0432\u043E\u0434\u0438\u043C \u0446\u0438\u0444\u0440\u044B \u0438\u0437 \u043F\u043E\u0447\u0442\u044B 2 \u043F\u043E\u043F\u044B\u0442\u043A\u0438 </p>`);
      if (!unref(isHideInput)) {
        _push(`<input${ssrRenderAttr("value", unref(token))} autocomplete="off">`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isHideInput)) {
        _push(`<button${ssrIncludeBooleanAttr(unref(disabled)) ? " disabled" : ""}>\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u043A\u043E\u0434</button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isHideInput)) {
        _push(`<p>\u0417\u0430\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u043A\u043E\u0434 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043C\u043E\u0436\u043D\u043E \u0431\u0443\u0434\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 ${ssrInterpolate(unref(timer))} \u0441\u0435\u043A</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<hr> pending: ${ssrInterpolate(unref(pending))} <br> resp: ${ssrInterpolate(unref(resp))}<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/site/user/auth/confirmUserRegistration.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=confirmUserRegistration-8ab86753.mjs.map
