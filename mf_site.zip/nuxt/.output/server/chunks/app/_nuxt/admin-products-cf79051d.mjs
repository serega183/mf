import { u as useSeoMeta, b as useRouter, _ as __nuxt_component_0 } from '../server.mjs';
import { withAsyncContext, withCtx, createTextVNode, unref, useSSRContext } from 'vue';
import { a as useLazyAsyncData } from './asyncData-b6294b3f.mjs';
import { o as onlyForAdmin } from './onlyForAdmin-250922f8.mjs';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "admin-products",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useSeoMeta({
      title: `\u0422\u043E\u0432\u0430\u0440\u044B`
    });
    useRouter();
    const { data: products, refresh: refreshProducts } = ([__temp, __restore] = withAsyncContext(() => useLazyAsyncData("products", () => $fetch("/api/db_products/productsAskAll"), { method: "get" })), __temp = await __temp, __restore(), __temp);
    onlyForAdmin();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<!--[--><h2> admin products </h2>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/admin/db-products/products/add-product" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Add products`);
          } else {
            return [
              createTextVNode("Add products")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<ol><!--[-->`);
      ssrRenderList(unref(products), (product) => {
        _push(`<li><hr><h4>${ssrInterpolate(product.name)}</h4><img${ssrRenderAttr("src", product.image)} alt=""><button>\u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C</button> <button>\u0443\u0434\u0430\u043B\u0438\u0442\u044C</button><br><!--[-->`);
        ssrRenderList(product, (value, name, index) => {
          _push(`<span>${ssrInterpolate(name)}: ${ssrInterpolate(value)} | </span>`);
        });
        _push(`<!--]--><hr></li>`);
      });
      _push(`<!--]--></ol><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/db-products/products/admin-products.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=admin-products-cf79051d.mjs.map
