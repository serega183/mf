import { u as useSeoMeta, _ as __nuxt_component_0 } from '../server.mjs';
import { o as onlyForAdmin } from './onlyForAdmin-250922f8.mjs';
import { withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: `\u0410\u0434\u043C\u0438\u043D\u043A\u0430`
    });
    onlyForAdmin();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<!--[--><h2> admin </h2>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/admin/db-products" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0411\u0414 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432`);
          } else {
            return [
              createTextVNode("\u0411\u0414 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/admin/db-users" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0411\u0414 \u043F\u043E\u043B\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439`);
          } else {
            return [
              createTextVNode("\u0411\u0414 \u043F\u043E\u043B\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/admin/db-orders/db-orders" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0411\u0414 \u0417\u0430\u043A\u0430\u0437\u044B`);
          } else {
            return [
              createTextVNode("\u0411\u0414 \u0417\u0430\u043A\u0430\u0437\u044B")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-03b731fa.mjs.map
