import { _ as __nuxt_component_0 } from './InputTextField-05fd2b85.mjs';
import { u as useSeoMeta } from '../server.mjs';
import { ref, unref, useSSRContext } from 'vue';
import { m as myCompValidate } from './myCompValidate-4ab9fb1a.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'requrl';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'node:fs';
import 'node:url';
import 'pathe';
import './fetch-fbd89f81.mjs';
import './asyncData-b6294b3f.mjs';

const _sfc_main = {
  __name: "test2copy",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: `\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u043E\u043B\u0435\u0439`
    });
    const textField = ref({
      name: "",
      age: ""
    });
    let errFields = ref({});
    async function testFF(write, fieldKey) {
      const apiDalee = "/api/test/testApiDalee";
      const fields = ref({});
      if (fieldKey) {
        fields.value[fieldKey] = category.value[fieldKey];
        errFields.value[fieldKey] = (await myCompValidate(apiDalee, fields, write))[fieldKey];
      } else {
        fields.value = category.value;
        errFields.value = await myCompValidate(apiDalee, fields, write);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_adminDbInputTextField = __nuxt_component_0;
      _push(`<!--[--><h4> test2copy </h4>`);
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "age",
        text: unref(textField).age,
        err: unref(errFields),
        placeholder: "\u0412\u043E\u0437\u0440\u0430\u0441\u0442",
        onUpdate: ($event) => {
          unref(textField).age = $event;
          testFF(false, "age");
        }
      }, null, _parent));
      _push(`<hr>`);
      _push(ssrRenderComponent(_component_adminDbInputTextField, {
        nazv: "name",
        text: unref(textField).name,
        err: unref(errFields),
        placeholder: "\u0418\u043C\u044F",
        onUpdate: ($event) => {
          unref(textField).name = $event;
          testFF(false, "name");
        }
      }, null, _parent));
      _push(`<hr><button>myCompValidate()</button><br><br><br> \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: ${ssrInterpolate(unref(errFields))}<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/test2copy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=test2copy-0deda778.mjs.map
