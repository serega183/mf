import { d as useAuth, n as navigateTo } from '../server.mjs';

function onlyForAdmin() {
  const { data } = useAuth();
  if (data.value.user.role != "admin") {
    alert("\u0422\u044B \u043D\u0435 \u0430\u0434\u043C\u0438\u043D! \u0414\u043E\u0441\u0442\u0443\u043F \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D!");
    navigateTo({
      path: "/"
    });
  }
}

export { onlyForAdmin as o };
//# sourceMappingURL=onlyForAdmin-250922f8.mjs.map
