const client_manifest = {
  "_InputTextField.b3473f5d.js": {
    "resourceType": "script",
    "module": true,
    "file": "InputTextField.b3473f5d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_addToCart.5bb6064e.js": {
    "resourceType": "script",
    "module": true,
    "file": "addToCart.5bb6064e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_asyncData.4bcb0f60.js": {
    "resourceType": "script",
    "module": true,
    "file": "asyncData.4bcb0f60.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_fetch.5941ef4d.js": {
    "resourceType": "script",
    "module": true,
    "file": "fetch.5941ef4d.js",
    "imports": [
      "_asyncData.4bcb0f60.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_findProduct.cc2fdb7d.js": {
    "resourceType": "script",
    "module": true,
    "file": "findProduct.cc2fdb7d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.821d2340.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.821d2340.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_myCompValidate.2fff5c88.js": {
    "resourceType": "script",
    "module": true,
    "file": "myCompValidate.2fff5c88.js",
    "imports": [
      "_fetch.5941ef4d.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_onlyForAdmin.f12b94ea.js": {
    "resourceType": "script",
    "module": true,
    "file": "onlyForAdmin.f12b94ea.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_textField.b7ec67c2.js": {
    "resourceType": "script",
    "module": true,
    "file": "textField.b7ec67c2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/custom.vue": {
    "resourceType": "script",
    "module": true,
    "file": "custom.895de28f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/custom.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.356d8e3c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/withoutсart.vue": {
    "resourceType": "script",
    "module": true,
    "file": "withoutсart.fb0919c0.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/withoutсart.vue"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.9dfe013a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.b2ecc214.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "layouts/custom.vue",
      "layouts/default.vue",
      "layouts/withoutсart.vue",
      "virtual:nuxt:/var/www/01_sites_local/mf/mf_site/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.2372ea7c.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "pages/admin/db-orders/db-orders.css": {
    "resourceType": "style",
    "file": "db-orders.c1c4600b.css",
    "src": "pages/admin/db-orders/db-orders.css"
  },
  "pages/admin/db-orders/db-orders.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "db-orders.7b3e1916.js",
    "imports": [
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_onlyForAdmin.f12b94ea.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-orders/db-orders.vue"
  },
  "db-orders.c1c4600b.css": {
    "file": "db-orders.c1c4600b.css",
    "resourceType": "style"
  },
  "pages/admin/db-products/categories/add-category.vue": {
    "resourceType": "script",
    "module": true,
    "file": "add-category.4f6caa47.js",
    "imports": [
      "_InputTextField.b3473f5d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_myCompValidate.2fff5c88.js",
      "_onlyForAdmin.f12b94ea.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/categories/add-category.vue"
  },
  "pages/admin/db-products/categories/admin-categories.vue": {
    "resourceType": "script",
    "module": true,
    "file": "admin-categories.f18ddcde.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js",
      "_asyncData.4bcb0f60.js",
      "_fetch.5941ef4d.js",
      "_onlyForAdmin.f12b94ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/categories/admin-categories.vue"
  },
  "pages/admin/db-products/categories/edit_category/[id_category].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_category_.09df92a4.js",
    "imports": [
      "_InputTextField.b3473f5d.js",
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_myCompValidate.2fff5c88.js",
      "_onlyForAdmin.f12b94ea.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/categories/edit_category/[id_category].vue"
  },
  "pages/admin/db-products/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.13673b93.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js",
      "_onlyForAdmin.f12b94ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/index.vue"
  },
  "pages/admin/db-products/products/add-product.vue": {
    "resourceType": "script",
    "module": true,
    "file": "add-product.48b9c4ff.js",
    "imports": [
      "_InputTextField.b3473f5d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js",
      "_fetch.5941ef4d.js",
      "_myCompValidate.2fff5c88.js",
      "_onlyForAdmin.f12b94ea.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/products/add-product.vue"
  },
  "pages/admin/db-products/products/admin-prod-category/[cat_name].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_cat_name_.a4d64874.js",
    "imports": [
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_onlyForAdmin.f12b94ea.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/products/admin-prod-category/[cat_name].vue"
  },
  "pages/admin/db-products/products/admin-products-categories.vue": {
    "resourceType": "script",
    "module": true,
    "file": "admin-products-categories.cf536574.js",
    "imports": [
      "_index.821d2340.js",
      "_asyncData.4bcb0f60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_onlyForAdmin.f12b94ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/products/admin-products-categories.vue"
  },
  "pages/admin/db-products/products/admin-products.vue": {
    "resourceType": "script",
    "module": true,
    "file": "admin-products.66337e37.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js",
      "_asyncData.4bcb0f60.js",
      "_fetch.5941ef4d.js",
      "_onlyForAdmin.f12b94ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/products/admin-products.vue"
  },
  "pages/admin/db-products/products/edit-product/[id_product].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_product_.e5cf52e6.js",
    "imports": [
      "_InputTextField.b3473f5d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js",
      "_fetch.5941ef4d.js",
      "_myCompValidate.2fff5c88.js",
      "_onlyForAdmin.f12b94ea.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-products/products/edit-product/[id_product].vue"
  },
  "pages/admin/db-users/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.5cf2a8cc.js",
    "imports": [
      "_onlyForAdmin.f12b94ea.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/db-users/index.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.5fb7eb44.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js",
      "_onlyForAdmin.f12b94ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.686af624.js",
    "imports": [
      "_findProduct.cc2fdb7d.js",
      "_index.821d2340.js",
      "_asyncData.4bcb0f60.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/pluginTest.vue": {
    "resourceType": "script",
    "module": true,
    "file": "pluginTest.4bfd62c6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/pluginTest.vue"
  },
  "pages/site/findered-products.vue": {
    "resourceType": "script",
    "module": true,
    "file": "findered-products.caae05d0.js",
    "imports": [
      "_findProduct.cc2fdb7d.js",
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_addToCart.5bb6064e.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/findered-products.vue"
  },
  "pages/site/products-category/[cat_name].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_cat_name_.532cd738.js",
    "imports": [
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_addToCart.5bb6064e.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/products-category/[cat_name].vue"
  },
  "pages/site/user/auth/confirmUserRegistration.vue": {
    "resourceType": "script",
    "module": true,
    "file": "confirmUserRegistration.8a152026.js",
    "imports": [
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/auth/confirmUserRegistration.vue"
  },
  "pages/site/user/auth/forgot-pass.vue": {
    "resourceType": "script",
    "module": true,
    "file": "forgot-pass.7d5b0d07.js",
    "imports": [
      "_textField.b7ec67c2.js",
      "_index.821d2340.js",
      "_myCompValidate.2fff5c88.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/auth/forgot-pass.vue"
  },
  "pages/site/user/auth/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.9b4d8fea.js",
    "imports": [
      "_textField.b7ec67c2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/auth/login.vue"
  },
  "pages/site/user/auth/registration.vue": {
    "resourceType": "script",
    "module": true,
    "file": "registration.c11576b9.js",
    "imports": [
      "_textField.b7ec67c2.js",
      "_index.821d2340.js",
      "_myCompValidate.2fff5c88.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/auth/registration.vue"
  },
  "pages/site/user/cabinet.vue": {
    "resourceType": "script",
    "module": true,
    "file": "cabinet.a246b083.js",
    "imports": [
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/cabinet.vue"
  },
  "pages/site/user/cart.vue": {
    "resourceType": "script",
    "module": true,
    "file": "cart.5157cd18.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/cart.vue"
  },
  "pages/site/user/making-order.vue": {
    "resourceType": "script",
    "module": true,
    "file": "making-order.0c801449.js",
    "imports": [
      "_textField.b7ec67c2.js",
      "_index.821d2340.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_myCompValidate.2fff5c88.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/making-order.vue"
  },
  "pages/site/user/order-complite.vue": {
    "resourceType": "script",
    "module": true,
    "file": "order-complite.8db43d3f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.821d2340.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/site/user/order-complite.vue"
  },
  "pages/test.vue": {
    "resourceType": "script",
    "module": true,
    "file": "test.3862a7a2.js",
    "imports": [
      "_index.821d2340.js",
      "_fetch.5941ef4d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/test.vue"
  },
  "pages/test2copy.vue": {
    "resourceType": "script",
    "module": true,
    "file": "test2copy.efbd2192.js",
    "imports": [
      "_InputTextField.b3473f5d.js",
      "_index.821d2340.js",
      "_myCompValidate.2fff5c88.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.5941ef4d.js",
      "_asyncData.4bcb0f60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/test2copy.vue"
  },
  "virtual:nuxt:/var/www/01_sites_local/mf/mf_site/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.ffb7c277.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/var/www/01_sites_local/mf/mf_site/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
