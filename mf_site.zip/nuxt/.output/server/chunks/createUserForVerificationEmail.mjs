import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const createUserForVerificationEmail = defineEventHandler(async (event) => {
  const user = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  const token = `${randomInteger(0, 9)}${randomInteger(0, 9)}${randomInteger(0, 9)}${randomInteger(
    0,
    9
  )}`;
  console.log("token:", token);
  try {
    const [rows] = await con.execute(
      `select * from usersNoVerificatedEmail WHERE email='${user.email.input}'`
    );
    let data = [];
    let sql = ``;
    if (!rows[0]) {
      data = [user.email.input, user.name.input, user.phone.input, user.pass.input, token];
      sql = `INSERT INTO usersNoVerificatedEmail SET email=?, name=?, phone=?, password=?, token=?`;
    } else {
      data = [user.name.input, user.phone.input, user.pass.input, token];
      sql = `UPDATE usersNoVerificatedEmail SET name=?, phone=?, password=?, token=? WHERE email='${user.email.input}'`;
    }
    const add = await con.query(sql, data);
    con.end();
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. usersNoVerificatedEmail. ${error}`;
  }
  const sendMailVerification = await $fetch("/api/auth/sendMailVerification", {
    method: "POST",
    body: { email: user.email.input, token }
  });
  return sendMailVerification;
});
function randomInteger(min, max) {
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
}

export { createUserForVerificationEmail as default };
//# sourceMappingURL=createUserForVerificationEmail.mjs.map
