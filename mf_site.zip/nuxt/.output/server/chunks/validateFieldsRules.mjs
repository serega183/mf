import { defineEventHandler, readBody } from 'h3';

const validateFieldsRules = defineEventHandler(async (event) => {
  const { fields } = await readBody(event);
  const errorsFields = {};
  for (const field in fields) {
    errorsFields[field] = [];
    if (!fields[field].needValidate)
      continue;
    const needValidate = fields[field].needValidate;
    if (needValidate.minLength) {
      if (minLength(fields[field].input, fields[field].needValidate.minLength) !== true) {
        errorsFields[field].push(
          minLength(fields[field].input, fields[field].needValidate.minLength)
        );
      }
    }
    if (needValidate.isEmpty) {
      if (isEmpty(fields[field].input) !== true) {
        errorsFields[field].push(isEmpty(fields[field].input));
      }
    }
    if (needValidate.isDigit) {
      if (isDigit(fields[field].input) !== true) {
        errorsFields[field].push(isDigit(fields[field].input));
      }
    }
    if (needValidate.isStock) {
      if (isStock(fields[field].input) !== true) {
        errorsFields[field].push(isStock(fields[field].input));
      }
    }
    if (needValidate.isRating) {
      if (isRating(fields[field].input) !== true) {
        errorsFields[field].push(isRating(fields[field].input));
      }
    }
    if (needValidate.isCheckCategory) {
      if (isCheckCategory(fields[field].input) !== true) {
        errorsFields[field].push(isCheckCategory(fields[field].input));
      }
    }
    if (needValidate.isPhone) {
      if (isPhone(fields[field].input) !== true) {
        errorsFields[field].push(isPhone(fields[field].input));
      }
    }
    if (needValidate.isEmail) {
      if (isEmail(fields[field].input) !== true) {
        errorsFields[field].push(isEmail(fields[field].input));
      }
    }
  }
  const errFields = {};
  for (const field in errorsFields) {
    if (errorsFields[field].length > 0) {
      errFields[field] = errorsFields[field];
    }
  }
  return Object.keys(errFields).length ? errFields : `\u0412\u0441\u0435 \u043F\u043E\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u044B \u0432\u0435\u0440\u043D\u043E`;
});
const minLength = (input, length) => {
  if (input.length < length) {
    return `\u0422\u0435\u043A\u0441\u0442 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043D\u0435 \u043C\u0435\u043D\u0435\u0435 ${length} \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432`;
  }
  return true;
};
function isEmpty(input) {
  if (input.length == 0) {
    return `\u041F\u0443\u0441\u0442\u043E\u0435 \u043F\u043E\u043B\u0435 \u043D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E`;
  }
  return true;
}
function isDigit(input) {
  if (Number.isNaN(Number(input))) {
    return `\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043B\u043E\u0435 \u0447\u0438\u0441\u043B\u043E`;
  }
  return true;
}
function isStock(input) {
  if (input != 1 && input != 0) {
    return `0 - \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0440\u0430\u0441\u043F\u0440\u043E\u0434\u0430\u0436\u0443, 1 - \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0440\u0430\u0441\u043F\u0440\u043E\u0434\u0430\u0436\u0443`;
  }
  return true;
}
function isRating(input) {
  if (input > 10 || input < 0) {
    return `\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0447\u0438\u0441\u043B\u043E \u043E\u0442 0 \u0434\u043E 10`;
  }
  return true;
}
function isCheckCategory(input) {
  if (input.length == 0) {
    return `\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438(\u0438/\u044E)`;
  }
  return true;
}
function isPhone(input) {
  if (input[0] != 8) {
    return "\u041D\u043E\u043C\u0435\u0440 \u0434\u043E\u043B\u0436\u0435\u043D \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 8";
  }
  if (Number.isNaN(Number(input))) {
    return "\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0446\u0438\u0444\u0440\u044B";
  }
  if (input.length != 11) {
    return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 11 \u0446\u0438\u0444\u0440";
  }
  return true;
}
function isEmail(input) {
  const EMAIL_REGEXP = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/iu;
  if (!EMAIL_REGEXP.test(input)) {
    return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043A\u043E\u0440\u0435\u043A\u0442\u043D\u044B\u0439 email";
  }
  return true;
}

export { validateFieldsRules as default };
//# sourceMappingURL=validateFieldsRules.mjs.map
