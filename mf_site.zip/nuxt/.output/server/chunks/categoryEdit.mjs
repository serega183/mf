import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const categoryEdit = defineEventHandler(async (event) => {
  const { fields, write } = await readBody(event);
  if (typeof fields["cat_name"] !== "undefined") {
    fields.cat_name.needValidate = {
      minLength: 3
    };
  }
  const validatefields = await $fetch("/api/validateFieldsRules", {
    method: "POST",
    body: { fields }
  });
  if (validatefields instanceof Object) {
    return validatefields;
  } else {
    if (write) {
      const data = [fields.cat_name.input, fields.cat_discr.input, fields.cat_img.input];
      const sql = `UPDATE categories SET cat_name=?, cat_discr=?, cat_img=? WHERE id_cat=${fields.id_cat.input}`;
      try {
        const runtimeConfig = useRuntimeConfig();
        const con2 = await mysql.createConnection({
          host: runtimeConfig.mysqlHost,
          port: runtimeConfig.mysqlPort,
          user: runtimeConfig.mysqlUser,
          password: runtimeConfig.mysqlPassword,
          database: runtimeConfig.mysqlDatabase
        });
        const edit = await con2.query(sql, data);
        con2.end();
        return true;
      } catch (error) {
        con.end();
        return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. categoryEdit. ${error}`;
      }
    }
    return validatefields;
  }
});

export { categoryEdit as default };
//# sourceMappingURL=categoryEdit.mjs.map
