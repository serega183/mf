import { defineEventHandler } from 'h3';
import nodemailer from 'nodemailer';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const sendMail = defineEventHandler((event) => {
  const runtimeConfig = useRuntimeConfig();
  async function main() {
    await nodemailer.createTestAccount();
    let transporter = nodemailer.createTransport({
      host: runtimeConfig.emailHost,
      port: runtimeConfig.emailPort,
      secure: runtimeConfig.emailSecure,
      // true for 465, false for other ports
      auth: {
        user: runtimeConfig.emailUser,
        // generated ethereal user
        pass: runtimeConfig.emailPass
        // generated ethereal password
      }
    });
    let info = await transporter.sendMail({
      from: '"Fred Foo \u{1F47B}" <admin@serega183.ru>',
      // sender address
      to: "serega183@mail.ru",
      // list of receivers
      subject: "Hello \u2714",
      // Subject line
      text: `Hello world?`,
      // plain text body
      html: "<b>Hello world?</b>"
      // html body
    });
    console.log("Message sent: %s", info.messageId);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  }
  main().catch(console.error);
});

export { sendMail as default };
//# sourceMappingURL=sendMail.mjs.map
