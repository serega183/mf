import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { g as getServerSession, a as getToken, u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const ordersAll = defineEventHandler(async (event) => {
  const resp = {
    err: null,
    resp: null
  };
  const session = await getServerSession(event);
  if (!session) {
    resp.err = "unauthenticated";
    return resp;
  }
  console.log(session.role);
  await getToken({ event });
  const { filterStatus, filterDate } = await readBody(event);
  const runtimeConfig = useRuntimeConfig();
  const con = await mysql.createConnection({
    host: runtimeConfig.mysqlHost,
    port: runtimeConfig.mysqlPort,
    user: runtimeConfig.mysqlUser,
    password: runtimeConfig.mysqlPassword,
    database: runtimeConfig.mysqlDatabase
  });
  let sql = ``;
  if (filterDate == "\u0412\u0441\u0435" && filterStatus == "\u0412\u0441\u0435") {
    sql = `select * from orders`;
  } else if (filterDate == "\u0412\u0441\u0435" && filterStatus != "\u0412\u0441\u0435") {
    sql = `select * from orders WHERE status='${filterStatus}'`;
  } else if (filterDate != "\u0412\u0441\u0435" && filterStatus == "\u0412\u0441\u0435") {
    sql = `select * from orders WHERE date BETWEEN '${filterDate.ot}' AND '${filterDate.do}'`;
  } else if (filterDate != "\u0412\u0441\u0435" && filterStatus != "\u0412\u0441\u0435") {
    sql = `select * from orders WHERE date BETWEEN '${filterDate.ot}' AND '${filterDate.do}' AND status='${filterStatus}'`;
  }
  try {
    const [rows] = await con.query(sql);
    resp.resp = rows;
    con.end();
    return resp;
  } catch (error) {
    resp.err = `\u041E\u0448\u0438\u0431\u043A\u0430 \u0447\u0442\u0435\u043D\u0438\u044F \u0431\u0430\u0437\u044B. ordersAll. ${error}`;
    return resp;
  }
});

export { ordersAll as default };
//# sourceMappingURL=ordersAll.mjs.map
