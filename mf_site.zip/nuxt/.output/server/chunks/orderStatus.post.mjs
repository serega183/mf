import { defineEventHandler, readBody } from 'h3';
import mysql from 'mysql2/promise';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'next-auth/core';
import 'next-auth/jwt';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'pathe';

const orderStatus_post = defineEventHandler(async (event) => {
  const { id, status } = await readBody(event);
  console.log(id, status);
  const sql = `UPDATE orders SET status=? WHERE id=${id}`;
  try {
    const runtimeConfig = useRuntimeConfig();
    const con2 = await mysql.createConnection({
      host: runtimeConfig.mysqlHost,
      port: runtimeConfig.mysqlPort,
      user: runtimeConfig.mysqlUser,
      password: runtimeConfig.mysqlPassword,
      database: runtimeConfig.mysqlDatabase
    });
    const edit = await con2.query(sql, status);
    con2.end();
    return true;
  } catch (error) {
    con.end();
    return `\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0431\u0430\u0437\u0443. categoryEdit. ${error}`;
  }
});

export { orderStatus_post as default };
//# sourceMappingURL=orderStatus.post.mjs.map
