import{W as o,R as t}from"./entry.2372ea7c.js";function n(){const{data:a}=o();a.value.user.role!="admin"&&(alert("Ты не админ! Доступ запрещён!"),t({path:"/"}))}export{n as o};
