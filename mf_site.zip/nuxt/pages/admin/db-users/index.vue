<template>
    <h2>
        db-users
    </h2>
</template>

<script setup>
// УДВЛЕНИЕ НЕ ВЛИЯЕТ НА ОШИБКИ
// CUSTOM LAYOUT не работает также
definePageMeta({
    layout: "default",
});
onlyForAdmin();
</script>