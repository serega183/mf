export const useFoomyServerUtils = (mes) => {
  return `myServerUtils: ${mes}`;
};
export function test01server(data) {
  console.log("test01server" + data);
}
