export const useFoomyServerUtils = (mes) => {
  return `serverUtils: ${mes}`;
};
export function test01server(data) {
  console.log("test01server" + data);
}
