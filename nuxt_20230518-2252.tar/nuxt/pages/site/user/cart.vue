<template>
    <div v-if="Object.keys(storeCart.cart).length">
        Корзина:
        <div v-for="(cnt, id) in storeCart.cart" :key="'cnt' + id">
            id:{{ id }}, count:{{ cnt }}
            <br>
            <button v-if="storeCart.cart[id].count > 1" @click="plusMinusCount('minus', id)">minusCount</button>
            <button v-else @click="removeFromCart(id)">removeFromCart</button>
            <button @click="plusMinusCount('plus', id)">plusCount</button>
            <hr>
        </div>
        <NuxtLink to="/site/user/making-order">Оформить</NuxtLink>
    </div>
    <div v-else>Корзина пуста</div>
</template>

<script setup>

definePageMeta({
    layout: "withoutсart",
    auth: false
});
useSeoMeta({
    title: `Корзина`
})
const storeCart = usePiniaCart();

</script>