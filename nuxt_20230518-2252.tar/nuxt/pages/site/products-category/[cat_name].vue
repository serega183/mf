<template>
    <h2>
        {{ route.params.cat_name }}
    </h2>
    <div v-if="!pending">
        <div v-if="products.length > 0">
            <div class="product-card" v-for="(product, index) in products" :key="'product' + index">
                <h3>{{ product.name }}</h3>
                <img :src="product.image" alt="">
                <div>{{ product.edinic }}{{ product.units }}</div>
                <div>Остаток: {{ product.balance }}</div>
                <div>Описание: {{ product.description }}</div>
                <div>Производитель: {{ product.maker }}</div>
                <div v-if="product.param1">
                    <div v-for="(param, index) in params(product.param1)" :key="'param1' + index" :class="[{ activeClass: isActive(param, product.param1select) }, 'button']" @click="product.param1select = param">{{ param }}
                    </div>
                </div>
                <div v-if="product.param2">
                    <div v-for="(param, index) in params(product.param2)" :key="'param2' + index" :class="[{ activeClass: isActive(param, product.param2select) }, 'button']" @click="product.param2select = param">
                        {{ param }}
                    </div>
                </div>
                <div v-if="product.param3">
                    <div v-for="(param, index) in params(product.param3)" :key="'param3' + index" :class="[{ activeClass: isActive(param, product.param3select) }, 'button']" @click="product.param3select = param">{{ param }}
                    </div>
                </div>
                <hr>
                <div>Цена: {{ product.price }} руб</div>
                <div class="button" @click="addToCart(product)">В корзину</div>
            </div>
        </div>
        <div v-else>В этой категории нет товаров</div>
    </div>
    <div v-else>Загрузка...</div>
    <!-- передаём в компонент TextArea строку и возвращаем редактированую -->
    <!--    <Custominput :text="product.name" @update="product.name = $event"></Custominput> -->

    <!--  -->
</template>

<script setup>
const route = useRoute();
const storeCart = usePiniaCart();
definePageMeta({
    layout: "default",
    auth: false
});
useSeoMeta({
    title: route.params.cat_name
})
/*  */
function params(param) {
    return param.split(',')
}
/*  */
function isActive(param, select) {
    if (param == select) {
        return true
    }
}

/*  */
function addToCart(product) {
    if (product.param1 && !product.param1select) {
        alert('выбирите цвет');
        return
    }
    if (product.param2 && !product.param2select) {
        alert('выбирите размер');
        return
    }
    if (product.param3 && !product.param3select) {
        alert('выбирите материал');
        return
    }
    let productsInCart = {};
    if (localStorage.getItem("products")) {
        //корзина есть парсим
        productsInCart = JSON.parse(localStorage.getItem("products"));
        // провнряем продукт
        if (typeof productsInCart[product.id] !== "undefined") {
            // продукт есть
            productsInCart[product.id].count++;
        } else {
            productsInCart[product.id] = { count: 1, product: product };
        }
    } else {
        productsInCart[product.id] = { count: 1, product: product };
    }
    localStorage.setItem("products", JSON.stringify(productsInCart));
    storeCart.cart = productsInCart;
}

/*  */


const { data: products, pending } = await useLazyFetch('/api/db_products/productsInCategoryAsk', { method: 'POST', body: { cat_name: route.params.cat_name } });



//products.value = await data.value;
//console.log(products.value);

/* const { data: products, pending, refresh: refreshProducts } = await useFetch('/api/products/productsInCatAsk', { method: 'GET', query: { cat_name: route.params.cat_name } }); */

//const products = ref([]);
/* const { data, pending, refresh: refreshProducts } = await useFetch(() => `/api/products/productsInCatAsk`, { query: { cat_name: route.params.cat_name } })
products.value = data.value; */
/*  */


</script>

<style>
.activeClass {
    background-color: rgb(143, 143, 143);
}

h3 {
    margin-bottom: 0.5em;
    color: #744faf;
}

.product-card {
    background-color: lightgray;
    margin: 1em 0em;
    padding: 0.5em 0.5em;
    border-radius: 0.5em;
}

img {
    width: 25%;
}
</style>