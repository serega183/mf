export default defineEventHandler((event) => {
  return `Поля успешно отправлены далее...`;
});
