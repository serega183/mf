export default defineEventHandler((event) => {
  // console.log("log server middleware");
  /*   const query = getQuery(event);
  console.log("--- Log: " + event.node.req.url);
  console.log(query);
  console.log("--------------"); */
  // async..await is not allowed in global scope, must use a wrapper
});
