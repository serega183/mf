const storeCart = usePiniaCart();
export default defineNuxtRouteMiddleware((to, from) => {
  if (!storeCart.token) {
    return navigateTo("/login");
  }

  /*   if (to.params.id === "1") {
    return abortNavigation();
  }
  return navigateTo("/"); */
});
