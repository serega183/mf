<template>
  <div>
    custom layout
    <div>
      <slot />
    </div>
  </div>
</template>
