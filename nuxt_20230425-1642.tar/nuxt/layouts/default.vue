<template>
  <div>
    default layouts
    <div>
      <UserCart></UserCart>
    </div>
    <div>
      <slot />
    </div>
  </div>
</template>
