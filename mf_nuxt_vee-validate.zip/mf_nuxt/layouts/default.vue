<template>
  <div>
    default layouts
    <div>
      <slot />
    </div>
  </div>
</template>
