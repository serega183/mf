<template>
    <h2>
        admin db-products
    </h2>
</template>

<script setup>
definePageMeta({
    layout: "default",
});
useSeoMeta({
    title: `БД товары`
})
</script>