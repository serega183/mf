//const storeCart = usePiniaCart();
export function utilsLog() {
  console.log("nuxt/utils/log.js");
  // console.log(from);
  //  console.log(to.path);
}
