<template>
    <h4>
        confirm
    </h4>
    <p>
        Подтвердите регистрацию через email, vk или ...через жопу
        <br> еще не придумал
        <br>
        пока в базу не записываю
    </p>
</template>

<script setup>

definePageMeta({
    layout: "default",
    auth: false
});
useSeoMeta({
    title: `Кабинет`
})
const storeCart = usePiniaCart();

</script>