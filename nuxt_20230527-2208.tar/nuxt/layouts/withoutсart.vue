<template>
  <slot />
  <div class="footer">
    footer
  </div>
</template>

<script setup>
//const { status, data, signIn, signOut, getSession } = useAuth();
</script>
